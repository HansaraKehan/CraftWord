//! WordCraft for Android: runs the shared egui UI (`wordcraft-ui-egui`) inside a NativeActivity.
//!
//! - File ▸ Open / Save As use Android's own file picker (no storage permission needed): the Java
//!   activity copies the chosen document to a private folder and writes later saves back to it. If the
//!   picker can't be shown, the built-in file browser is used (it needs "All files access").
//! - Files opened from other apps ("Open with" WordCraft) arrive through the Java activity, which
//!   copies them to a folder and hands the path over; `poll_open` picks it up on every few frames.
//! - Not yet: preferences file, printing.
#![cfg(target_os = "android")]

use std::path::PathBuf;
use std::sync::{Arc, Mutex, mpsc};
use std::time::{Duration, Instant};

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use wordcraft_engine::Session;
use wordcraft_ui_egui::{FileDialogAnswer, FileDialogRequest, Services, UiState, WordApp};

/// The answer channel of a file dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<FileDialogAnswer>>> = Mutex::new(None);

/// When the last formatted copy was put on the Android clipboard: egui also reports the plain text of
/// that copy, which must not replace it.
static HTML_COPIED: Mutex<Option<Instant>> = Mutex::new(None);

/// The repository this build came from (set by the workflow), whose Releases hold newer builds.
const REPO: &str = match option_env!("GITHUB_REPOSITORY") {
    Some(repo) => repo,
    None => "HansaraKehan/CraftWord",
};

/// A newer build of this app than the installed one.
struct UpdateOffer {
    tag: String,
    installed: String,
    page: String,
    apk: String,
}

/// What the user told the update check: a version to leave alone, and a time before which not to ask again.
#[derive(Default)]
struct UpdateChoice {
    skipped: String,
    remind_after: u64,
}

/// A button big enough for a finger.
fn touch_button(text: &str) -> egui::Button<'_> {
    egui::Button::new(text).min_size(egui::vec2(120.0, 44.0))
}

fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn load_update_choice(path: &std::path::Path) -> UpdateChoice {
    let value: serde_json::Value = std::fs::read(path).ok().and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_default();
    UpdateChoice {
        skipped: value.get("skipped").and_then(|v| v.as_str()).unwrap_or_default().to_string(),
        remind_after: value.get("remind_after").and_then(|v| v.as_u64()).unwrap_or(0),
    }
}

struct App {
    word: WordApp,
    android: AndroidApp,
    /// `<private>/config/ui.json`, the last bytes written to it, when we last looked, and whether it is
    /// safe to overwrite (it was missing or read fine).
    prefs_path: Option<PathBuf>,
    saved: Vec<u8>,
    last_check: Instant,
    prefs_ok: bool,
    /// Checking for a newer build: when the app started, whether the check was sent, the choice made earlier
    /// (kept in `update.json`), and the offer to show.
    launched: Instant,
    update_started: bool,
    update_choice: UpdateChoice,
    update_file: Option<PathBuf>,
    update_offer: Option<UpdateOffer>,
}

impl App {
    /// Android never closes the app politely, so the desktop's "save when quitting" never runs: write the
    /// interface settings and recent documents a few seconds after they change instead.
    fn remember_update_choice(&self) {
        let Some(path) = &self.update_file else { return };
        let value = serde_json::json!({ "skipped": self.update_choice.skipped, "remind_after": self.update_choice.remind_after });
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        let _ = std::fs::write(path, value.to_string());
    }

    /// A few seconds after start, ask GitHub for the newest release of this app, and offer it if it is not
    /// the installed one, unless the user skipped that version or asked to be reminded later.
    fn check_for_updates(&mut self) {
        if !self.update_started && self.launched.elapsed() > Duration::from_secs(5) {
            self.update_started = true;
            if now_secs() >= self.update_choice.remind_after {
                start_update_check(&self.android, REPO);
            }
        }
        if let Some(reply) = poll_update(&self.android)
            && let Some(rest) = reply.strip_prefix("OK\n")
        {
            let mut lines = rest.split('\n');
            let (tag, page, apk) = (lines.next().unwrap_or(""), lines.next().unwrap_or(""), lines.next().unwrap_or(""));
            let installed = read_string(&self.android, "installedVersion").unwrap_or_default();
            if !tag.is_empty() && tag != installed && tag != self.update_choice.skipped {
                self.update_offer = Some(UpdateOffer { tag: tag.to_string(), installed, page: page.to_string(), apk: apk.to_string() });
            }
        }
    }

    fn show_update_offer(&mut self, ctx: &egui::Context) {
        let Some(offer) = &self.update_offer else { return };
        enum Choice {
            Download,
            Later,
            Skip,
        }
        let mut choice = None;
        egui::Window::new("A new version is available")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
            .show(ctx, |ui| {
                ui.label("A newer build of WordCraft for Android is ready to download.");
                ui.add_space(4.0);
                ui.label(format!("Installed: {}", if offer.installed.is_empty() { "unknown" } else { &offer.installed }));
                ui.label(format!("New: {}", offer.tag));
                ui.add_space(8.0);
                ui.horizontal_wrapped(|ui| {
                    if ui.add(touch_button("Download")).clicked() {
                        choice = Some(Choice::Download);
                    }
                    if ui.add(touch_button("Remind me later")).clicked() {
                        choice = Some(Choice::Later);
                    }
                    if ui.add(touch_button("Skip this version")).clicked() {
                        choice = Some(Choice::Skip);
                    }
                });
            });
        let Some(choice) = choice else { return };
        let Some(offer) = self.update_offer.take() else { return };
        match choice {
            Choice::Download => {
                // The APK itself when the release has one, else the release page; ask again tomorrow if it was not installed.
                open_link(&self.android, if offer.apk.is_empty() { &offer.page } else { &offer.apk });
                self.update_choice.remind_after = now_secs() + 24 * 3600;
            }
            Choice::Later => self.update_choice.remind_after = now_secs() + 24 * 3600,
            Choice::Skip => self.update_choice.skipped = offer.tag,
        }
        self.remember_update_choice();
    }

    fn save_prefs(&mut self) {
        if !self.prefs_ok || self.last_check.elapsed() < Duration::from_secs(4) {
            return;
        }
        self.last_check = Instant::now();
        let Some(path) = &self.prefs_path else { return };
        let Ok(bytes) = serde_json::to_vec_pretty(&self.word.prefs()) else { return };
        if bytes == self.saved {
            return;
        }
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        // Temporary file, then rename: an interrupted write leaves the previous settings in place.
        let tmp = path.with_extension("json.tmp");
        if std::fs::write(&tmp, &bytes).and_then(|()| std::fs::rename(&tmp, path)).is_ok() {
            self.saved = bytes;
        }
    }
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android)
            && let Err(error) = self.word.run("file.open", serde_json::json!({ "path": path }))
        {
            log::warn!("open {path}: {error}");
        }
        if let Some(answer) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(answer);
        }
        self.word.logic(ctx);
        self.save_prefs();
        self.check_for_updates();
        // Wake now and then to see a document another app handed us.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        // Ctrl+V: egui only knows what was copied inside the app; paste what is on Android's clipboard.
        for event in raw.events.iter_mut() {
            if let egui::Event::Paste(text) = event
                && let Some(system) = clipboard_text(&self.android)
            {
                *text = system;
            }
        }
        self.word.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.word.ui(ui);
        open_links(ui.ctx(), &self.android);
        bridge_clipboard(ui.ctx(), &self.android);
        self.show_update_offer(ui.ctx());
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

/// Ask the Java activity for the next document opened from another app (a path, or nothing).
fn poll_open(app: &AndroidApp) -> Option<String> {
    let path = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })?;
    (!path.is_empty()).then_some(path)
}

/// Show Android's file picker. `false` means it could not be opened.
fn start_pick(app: &AndroidApp, save: bool, name: &str, purpose: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        let purpose = env.new_string(purpose)?;
        env.call_method(
            activity,
            "startPick",
            "(ZLjava/lang/String;Ljava/lang/String;)V",
            &[JValue::Bool(u8::from(save)), JValue::from(&name), JValue::from(&purpose)],
        )?;
        Ok(())
    })
    .is_some()
}

/// The picker's answer once it has closed: the path to open or save to, or cancelled.
fn poll_pick(app: &AndroidApp) -> Option<FileDialogAnswer> {
    let answer = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollPick", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let answer: String = env.get_string(&text)?.into();
        Ok(answer)
    })?;
    if answer.is_empty() {
        return None;
    }
    // The paths picked, one per line; nothing at all means the dialog was cancelled.
    Some(Ok(answer.strip_prefix("OK\n").map(|paths| paths.split('\n').filter(|p| !p.is_empty()).map(str::to_string).collect()).unwrap_or_default()))
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

/// The text on Android's clipboard, if any.
fn clipboard_text(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardText").filter(|text| !text.is_empty())
}

/// The formatted (HTML) copy on Android's clipboard, if another app put one there.
fn clipboard_html(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardHtml").filter(|html| !html.is_empty())
}

/// Put text (and, if given, its HTML) on Android's clipboard.
fn set_clipboard(app: &AndroidApp, text: &str, html: Option<&str>) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(text)?;
        let html = env.new_string(html.unwrap_or(""))?;
        env.call_method(activity, "setClipboard", "(Ljava/lang/String;Ljava/lang/String;)V", &[JValue::from(&text), JValue::from(&html)])?;
        Ok(())
    })
    .is_some()
}

/// What WordCraft copies (egui's "copy text" requests) goes on Android's clipboard for other apps.
fn bridge_clipboard(ctx: &egui::Context, app: &AndroidApp) {
    let formatted_just_now = HTML_COPIED.lock().ok().and_then(|at| *at).is_some_and(|at| at.elapsed() < Duration::from_millis(1500));
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::CopyText(text) => {
                if !formatted_just_now {
                    set_clipboard(app, text, None);
                }
                false
            }
            _ => true,
        });
    });
}

/// Ask the Java activity to look up the newest release of `repo` (the answer comes by `poll_update`).
fn start_update_check(app: &AndroidApp, repo: &str) {
    with_activity(app, |env, activity| {
        let repo = env.new_string(repo)?;
        env.call_method(activity, "startUpdateCheck", "(Ljava/lang/String;)V", &[JValue::from(&repo)])?;
        Ok(())
    });
}

/// The answer of the update check: "OK" with the tag, page and APK address on lines, or "NONE" when it failed.
fn poll_update(app: &AndroidApp) -> Option<String> {
    read_string(app, "pollUpdate").filter(|reply| !reply.is_empty())
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.hyperlink` and the app's own "open URL" requests end up as egui commands; open them here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("WordCraft").with_max_level(log::LevelFilter::Info));
    if std::env::var_os("HOME").is_none() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe { std::env::set_var("HOME", "/storage/emulated/0") };
    }
    let private = app.internal_data_path();
    if let Some(dir) = &private {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe {
            std::env::set_var("HOME", dir);
            std::env::set_var("XDG_CONFIG_HOME", dir.join("config"));
            std::env::set_var("XDG_DATA_HOME", dir.join("data"));
            std::env::set_var("XDG_CACHE_HOME", dir.join("cache"));
        }
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "WordCraft",
        options,
        Box::new(move |cc| {
            let region = wordcraft_ui_egui::i18n::system_region();
            let doc = wordcraft_engine::blank_document(&region);
            let mut session = Session::new(doc);
            session.system_region = region;
            // Android's own picker; if it can't be shown, answer with an error and the app uses its own browser.
            let ctx = cc.egui_ctx.clone();
            let picker = android.clone();
            let file_dialog: Box<dyn Fn(FileDialogRequest) -> mpsc::Receiver<FileDialogAnswer>> = Box::new(move |request| {
                let (answer, rx) = mpsc::channel();
                let (save, name, purpose) = match &request {
                    FileDialogRequest::Open { purpose } => (false, String::new(), purpose.clone()),
                    // Several files: the Java side sees the "multi:" prefix and lets the user pick more than one.
                    FileDialogRequest::OpenMany { purpose } => (false, String::new(), format!("multi:{purpose}")),
                    FileDialogRequest::Save { name, .. } => (true, name.clone(), String::new()),
                };
                let shown = start_pick(&picker, save, &name, &purpose);
                match (shown, EXTERNAL.lock()) {
                    (true, Ok(mut waiting)) => *waiting = Some(answer),
                    _ => {
                        let _ = answer.send(Err("no system file dialog on Android".to_string()));
                    }
                }
                ctx.request_repaint();
                rx
            });
            let (reader, html_reader, writer) = (android.clone(), android.clone(), android.clone());
            let services = Services {
                file_dialog: Some(file_dialog),
                // Paste from the ribbon and the context menu reads Android's clipboard.
                clipboard_text: Some(Box::new(move || clipboard_text(&reader))),
                clipboard_html: Some(Box::new(move || clipboard_html(&html_reader))),
                // (html, text, and for a copied equation its MathML: Android has no place for that, so it is not kept)
                set_clipboard_html: Some(Box::new(move |html: &str, text: &str, _mathml: &str| {
                    if let Ok(mut at) = HTML_COPIED.lock() {
                        *at = Some(Instant::now());
                    }
                    set_clipboard(&writer, text, Some(html))
                })),
                ..Default::default()
            };
            let mut word = WordApp::new(session, services);
            // Interface settings and recent documents saved by an earlier run.
            let prefs_path = private.as_ref().map(|dir| dir.join("config").join("ui.json"));
            let mut prefs_ok = prefs_path.is_some();
            if let Some(path) = &prefs_path
                && let Ok(bytes) = std::fs::read(path)
            {
                match UiState::from_json(&bytes) {
                    Some(ui) => word.apply_prefs(ui),
                    None => {
                        log::warn!("settings in {} could not be read; they will not be overwritten", path.display());
                        prefs_ok = false;
                    }
                }
            }
            // Autosaved copies of unsaved documents, offered again after a crash or a swiped-away app.
            if let Some(dir) = &private {
                let wake = cc.egui_ctx.clone();
                if let Err(error) = word.session.enable_recovery(dir.join("config").join("recovery"), Arc::new(move || wake.request_repaint())) {
                    log::warn!("local recovery unavailable: {error}");
                }
            }
            word.start_screen();
            let update_file = private.as_ref().map(|dir| dir.join("config").join("update.json"));
            let update_choice = update_file.as_deref().map(load_update_choice).unwrap_or_default();
            Ok(Box::new(App {
                word,
                android,
                prefs_path,
                saved: Vec::new(),
                last_check: Instant::now(),
                prefs_ok,
                launched: Instant::now(),
                update_started: false,
                update_choice,
                update_file,
                update_offer: None,
            }))
        }),
    );
    if let Err(error) = result {
        log::error!("WordCraft failed to start: {error}");
    }
}

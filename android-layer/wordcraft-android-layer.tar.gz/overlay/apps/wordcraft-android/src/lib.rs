//! WordCraft for Android: runs the shared egui UI (`wordcraft-ui-egui`) inside a NativeActivity.
//!
//! - File ▸ Open / Save As use Android's own file picker (no storage permission needed): the Java
//!   activity copies the chosen document to a private folder and writes later saves back to it. If the
//!   picker can't be shown, the built-in file browser is used (it needs "All files access").
//! - Files opened from other apps ("Open with" WordCraft) arrive through the Java activity, which
//!   copies them to a folder and hands the path over; `poll_open` picks it up on every few frames.
//! - Not yet: preferences file, printing.
#![cfg(target_os = "android")]

use std::path::PathBuf;
use std::sync::{Arc, Mutex, mpsc};
use std::time::{Duration, Instant};

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use wordcraft_engine::Session;
use wordcraft_ui_egui::paste_picture::ClipboardPicture;
use wordcraft_ui_egui::{FileDialogAnswer, FileDialogRequest, Services, UiState, WordApp};

/// The answer channel of a file dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<FileDialogAnswer>>> = Mutex::new(None);

/// How long a finger must stay still before it selects instead of scrolling.
const HOLD: f64 = 0.45;
/// How far (points) a finger may wander and still count as held.
const SLOP: f32 = 10.0;

#[derive(PartialEq)]
enum Mode {
    /// Down, not yet moved or held: could still be a tap, a scroll or a selection.
    Pending,
    /// Moving: the page scrolls with the finger.
    Scroll,
    /// Held still, then dragged: a real press, so the page selects text.
    Select,
}

/// One finger on the page, followed from touch-down.
struct Gesture {
    id: egui::TouchId,
    start: egui::Pos2,
    last: egui::Pos2,
    started_at: f64,
    mode: Mode,
    /// Whether holding still may start a text selection (the tool selects text).
    hold_selects: bool,
}

#[derive(Default)]
struct Touch {
    /// Fingers on the screen.
    fingers: u32,
    gesture: Option<Gesture>,
    /// The pointer events egui-winit makes from a finger that is scrolling are dropped, up to its `PointerGone`.
    drop_pointer: bool,
    /// Where a held finger lifted: the context menu (Copy, Highlight…) opens there.
    menu_at: Option<egui::Pos2>,
    /// Events held back for the next frames, so a press and its release never share a frame (the page view
    /// counts clicks from the press, as it would for a real tap).
    later: std::collections::VecDeque<Vec<egui::Event>>,
}

fn wheel(delta: egui::Vec2, phase: egui::TouchPhase, modifiers: egui::Modifiers) -> egui::Event {
    egui::Event::MouseWheel { unit: egui::MouseWheelUnit::Point, delta, phase, modifiers }
}

fn press(pos: egui::Pos2, button: egui::PointerButton, modifiers: egui::Modifiers) -> [egui::Event; 2] {
    [egui::Event::PointerMoved(pos), egui::Event::PointerButton { pos, button, pressed: true, modifiers }]
}

fn release(pos: egui::Pos2, button: egui::PointerButton, modifiers: egui::Modifiers) -> egui::Event {
    egui::Event::PointerButton { pos, button, pressed: false, modifiers }
}

/// When the last formatted copy was put on the Android clipboard: egui also reports the plain text of
/// that copy, which must not replace it.
static HTML_COPIED: Mutex<Option<Instant>> = Mutex::new(None);

/// The keyboard's clipboard strip (and pasted words) reach the app only through a real text connection: the Java
/// side wraps the app's view in a layout that owns it (see `ImeLayout`), and this side shows and hides the keyboard.
const IME_BRIDGE: bool = true;

/// The repository this build came from (set by the workflow), whose Releases hold newer builds.
const REPO: &str = match option_env!("GITHUB_REPOSITORY") {
    Some(repo) => repo,
    None => "HansaraKehan/CraftWord",
};

/// A newer build of this app than the installed one.
struct UpdateOffer {
    tag: String,
    installed: String,
    page: String,
    apk: String,
}

/// What the user told the update check: a version to leave alone, and a time before which not to ask again.
#[derive(Default)]
struct UpdateChoice {
    skipped: String,
    remind_after: u64,
}

/// A button big enough for a finger.
fn touch_button(text: &str) -> egui::Button<'_> {
    egui::Button::new(text).min_size(egui::vec2(120.0, 44.0))
}

fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn load_update_choice(path: &std::path::Path) -> UpdateChoice {
    let value: serde_json::Value = std::fs::read(path).ok().and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_default();
    UpdateChoice {
        skipped: value.get("skipped").and_then(|v| v.as_str()).unwrap_or_default().to_string(),
        remind_after: value.get("remind_after").and_then(|v| v.as_u64()).unwrap_or(0),
    }
}

struct App {
    word: WordApp,
    android: AndroidApp,
    /// `<private>/config/ui.json`, the last bytes written to it, when we last looked, and whether it is
    /// safe to overwrite (it was missing or read fine).
    prefs_path: Option<PathBuf>,
    saved: Vec<u8>,
    last_check: Instant,
    prefs_ok: bool,
    /// Checking for a newer build: when the app started, whether the check was sent, the choice made earlier
    /// (kept in `update.json`), and the offer to show.
    launched: Instant,
    update_started: bool,
    update_choice: UpdateChoice,
    update_file: Option<PathBuf>,
    update_offer: Option<UpdateOffer>,
    touch: Touch,
    last_autosave: Instant,
    /// The on-screen keyboard is wanted by the app; and the theme last written (a change is saved at once).
    ime_wanted: bool,
    last_theme: String,
}

impl App {
    /// On the page: a finger that moves scrolls it (as a trackpad swipe would), a tap clicks, and, where text
    /// can be selected, a finger held still starts a selection that the drag that follows extends. Everywhere
    /// else, and for a mouse or pen, input is left alone. The page view says where it is
    /// (`android.page_rect`: its area, and whether holding selects), for the Hand and text-selecting tools.
    fn filter_touch(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        let now = raw.time.unwrap_or(0.0);
        let page = ctx.data(|d| d.get_temp::<Option<(egui::Rect, bool)>>(egui::Id::new("android.page_rect"))).flatten();
        let modifiers = egui::Modifiers::NONE;
        let t = &mut self.touch;
        let mut out = Vec::with_capacity(raw.events.len() + 4);
        let mut tap: Option<egui::Pos2> = None;
        // The second half of a tap or a menu click made in an earlier frame.
        if let Some(batch) = t.later.pop_front() {
            out.extend(batch);
            if !t.later.is_empty() {
                ctx.request_repaint();
            }
        }
        for event in std::mem::take(&mut raw.events) {
            if let egui::Event::Touch { id, phase, pos, .. } = &event {
                match phase {
                    egui::TouchPhase::Start => {
                        t.fingers += 1;
                        // A second finger is a pinch: never a scroll or a selection.
                        t.gesture = (t.fingers == 1)
                            .then(|| page.filter(|(rect, _)| rect.contains(*pos)))
                            .flatten()
                            .map(|(_, hold_selects)| Gesture { id: *id, start: *pos, last: *pos, started_at: now, mode: Mode::Pending, hold_selects });
                        if t.fingers > 1 {
                            // A pinch needs a pointer position (the page only zooms under the pointer).
                            t.drop_pointer = false;
                            out.push(egui::Event::PointerMoved(*pos));
                        } else {
                            t.drop_pointer = t.gesture.is_some();
                        }
                    }
                    egui::TouchPhase::Move => {
                        if let Some(g) = t.gesture.as_mut()
                            && g.id == *id
                        {
                            match g.mode {
                                Mode::Pending if pos.distance(g.start) > SLOP => {
                                    g.mode = Mode::Scroll;
                                    // egui scrolls the area under the pointer: say where the finger is.
                                    out.push(egui::Event::PointerMoved(*pos));
                                    out.push(wheel(*pos - g.start, egui::TouchPhase::Start, modifiers));
                                    g.last = *pos;
                                }
                                Mode::Scroll => {
                                    out.push(egui::Event::PointerMoved(*pos));
                                    out.push(wheel(*pos - g.last, egui::TouchPhase::Move, modifiers));
                                    g.last = *pos;
                                }
                                _ => {}
                            }
                        }
                    }
                    egui::TouchPhase::End | egui::TouchPhase::Cancel => {
                        t.fingers = t.fingers.saturating_sub(1);
                        if let Some(g) = t.gesture.take_if(|g| g.id == *id) {
                            let ended = *phase == egui::TouchPhase::End;
                            match g.mode {
                                Mode::Pending if ended => {
                                    // A tap: press now, release in the next frame.
                                    out.extend(press(*pos, egui::PointerButton::Primary, modifiers));
                                    tap = Some(*pos);
                                    t.later.push_back(vec![release(*pos, egui::PointerButton::Primary, modifiers), egui::Event::PointerGone]);
                                    ctx.request_repaint();
                                }
                                Mode::Scroll => {
                                    out.push(wheel(egui::Vec2::ZERO, egui::TouchPhase::End, modifiers));
                                    out.push(egui::Event::PointerGone);
                                }
                                Mode::Select if ended => t.menu_at = Some(*pos),
                                _ => {}
                            }
                        }
                    }
                }
                // Touch events always go on: egui measures pinch zoom from them.
                out.push(event);
                continue;
            }
            if matches!(event, egui::Event::PointerGone) {
                // The finger is up. A held-then-selected text opens its menu (Copy, Highlight…) where it lifted.
                if let Some(pos) = t.menu_at.take() {
                    t.drop_pointer = false;
                    out.push(event);
                    out.extend(press(pos, egui::PointerButton::Secondary, modifiers));
                    t.later.push_back(vec![release(pos, egui::PointerButton::Secondary, modifiers)]);
                    ctx.request_repaint();
                    continue;
                }
                if t.drop_pointer && t.gesture.is_none() {
                    t.drop_pointer = false;
                    continue;
                }
            }
            let pointer_event = matches!(event, egui::Event::PointerMoved(_) | egui::Event::PointerButton { .. } | egui::Event::PointerGone);
            if pointer_event && t.drop_pointer && t.gesture.as_ref().is_none_or(|g| g.mode != Mode::Select) {
                continue;
            }
            out.push(event);
        }
        // Held still long enough: press where the finger went down, and let the drag extend the selection.
        if let Some(g) = t.gesture.as_mut()
            && g.mode == Mode::Pending
            && g.hold_selects
            && now - g.started_at >= HOLD
        {
            g.mode = Mode::Select;
            t.drop_pointer = false;
            out.extend(press(g.start, egui::PointerButton::Primary, modifiers));
        }
        if t.gesture.as_ref().is_some_and(|g| g.mode == Mode::Pending && g.hold_selects) {
            // No event arrives while the finger rests: wake up to notice the hold.
            ctx.request_repaint_after(Duration::from_millis(100));
        }
        raw.events = out;
        // Where a tap landed this frame (the page view clears its text selection there).
        ctx.data_mut(|d| d.insert_temp(egui::Id::new("android.tap_pos"), tap));
    }

    /// Android never closes the app politely, so the desktop's "save when quitting" never runs: write the
    /// interface settings and recent documents a few seconds after they change instead.
    fn remember_update_choice(&self) {
        let Some(path) = &self.update_file else { return };
        let value = serde_json::json!({ "skipped": self.update_choice.skipped, "remind_after": self.update_choice.remind_after });
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        let _ = std::fs::write(path, value.to_string());
    }

    /// A few seconds after start, ask GitHub for the newest release of this app, and offer it if it is not
    /// the installed one, unless the user skipped that version or asked to be reminded later.
    fn check_for_updates(&mut self) {
        if !self.update_started && self.launched.elapsed() > Duration::from_secs(5) {
            self.update_started = true;
            if now_secs() >= self.update_choice.remind_after {
                start_update_check(&self.android, REPO);
            }
        }
        if let Some(reply) = poll_update(&self.android)
            && let Some(rest) = reply.strip_prefix("OK\n")
        {
            let mut lines = rest.split('\n');
            let (tag, page, apk) = (lines.next().unwrap_or(""), lines.next().unwrap_or(""), lines.next().unwrap_or(""));
            let installed = read_string(&self.android, "installedVersion").unwrap_or_default();
            if !tag.is_empty() && tag != installed && tag != self.update_choice.skipped {
                self.update_offer = Some(UpdateOffer { tag: tag.to_string(), installed, page: page.to_string(), apk: apk.to_string() });
            }
        }
    }

    fn show_update_offer(&mut self, ctx: &egui::Context) {
        let Some(offer) = &self.update_offer else { return };
        enum Choice {
            Download,
            Later,
            Skip,
        }
        let mut choice = None;
        egui::Window::new("A new version is available")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
            .show(ctx, |ui| {
                ui.label("A newer build of WordCraft for Android is ready to download.");
                ui.add_space(4.0);
                ui.label(format!("Installed: {}", if offer.installed.is_empty() { "unknown" } else { &offer.installed }));
                ui.label(format!("New: {}", offer.tag));
                ui.add_space(8.0);
                ui.horizontal_wrapped(|ui| {
                    if ui.add(touch_button("Download")).clicked() {
                        choice = Some(Choice::Download);
                    }
                    if ui.add(touch_button("Remind me later")).clicked() {
                        choice = Some(Choice::Later);
                    }
                    if ui.add(touch_button("Skip this version")).clicked() {
                        choice = Some(Choice::Skip);
                    }
                });
            });
        let Some(choice) = choice else { return };
        let Some(offer) = self.update_offer.take() else { return };
        match choice {
            Choice::Download => {
                // The APK itself when the release has one, else the release page; ask again tomorrow if it was not installed.
                open_link(&self.android, if offer.apk.is_empty() { &offer.page } else { &offer.apk });
                self.update_choice.remind_after = now_secs() + 24 * 3600;
            }
            Choice::Later => self.update_choice.remind_after = now_secs() + 24 * 3600,
            Choice::Skip => self.update_choice.skipped = offer.tag,
        }
        self.remember_update_choice();
    }

    /// AutoSave is on by default but only covers a document that has a file. So a new document gets a file of its
    /// own the moment it has changes (no name asked for; `Save As` still renames it), and a document that was
    /// opened is saved once when first edited, which is what makes AutoSave keep writing to it.
    fn keep_autosave_on(&mut self) {
        if self.last_autosave.elapsed() < Duration::from_secs(2) || !self.word.autosave || !self.word.session.dirty {
            return;
        }
        self.last_autosave = Instant::now();
        match self.word.session.path.clone() {
            None => {
                if let Some(path) = read_string(&self.android, "newDocumentPath").filter(|p| !p.is_empty()) {
                    let _ = self.word.run("file.saveAs", serde_json::json!({ "path": path }));
                }
            }
            Some(path) => {
                if !self.word.saved_here() && wordcraft_ui_egui::keeps_everything(&path.to_string_lossy()) {
                    let _ = self.word.run("file.save", serde_json::json!({}));
                }
            }
        }
    }

    fn save_prefs(&mut self) {
        // A theme change is saved straight away; anything else within a few seconds.
        let theme = serde_json::to_string(&self.word.ui.theme).unwrap_or_default();
        let theme_changed = theme != self.last_theme;
        self.last_theme = theme;
        if !self.prefs_ok || (self.last_check.elapsed() < Duration::from_secs(4) && !theme_changed) {
            return;
        }
        self.last_check = Instant::now();
        let Some(path) = &self.prefs_path else { return };
        let Ok(bytes) = serde_json::to_vec_pretty(&self.word.prefs()) else { return };
        if bytes == self.saved {
            return;
        }
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        // Temporary file, then rename: an interrupted write leaves the previous settings in place.
        let tmp = path.with_extension("json.tmp");
        if std::fs::write(&tmp, &bytes).and_then(|()| std::fs::rename(&tmp, path)).is_ok() {
            self.saved = bytes;
        }
    }
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android)
            && let Err(error) = self.word.run("file.open", serde_json::json!({ "path": path }))
        {
            log::warn!("open {path}: {error}");
        }
        if let Some(answer) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(answer);
        }
        self.word.logic(ctx);
        self.save_prefs();
        self.check_for_updates();
        self.keep_autosave_on();
        // Wake now and then to see a document another app handed us.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.filter_touch(ctx, raw);
        if !raw.focused {
            // The app is going to the background, where Android may end it: save now.
            self.last_check = Instant::now().checked_sub(Duration::from_secs(10)).unwrap_or_else(Instant::now);
        }
        // Ctrl+V: egui only knows what was copied inside the app; paste what is on Android's clipboard.
        for event in raw.events.iter_mut() {
            if let egui::Event::Paste(text) = event
                && let Some(system) = clipboard_text(&self.android)
            {
                *text = system;
            }
        }
        // The keyboard may have been put away (back button, another app): a tap in the text brings it back.
        if IME_BRIDGE
            && self.ime_wanted
            && raw.events.iter().any(|e| matches!(e, egui::Event::Touch { phase: egui::TouchPhase::End, .. }))
        {
            show_keyboard(&self.android, true);
        }
        // Words and pastes from the on-screen keyboard (its clipboard strip) arrive through the hidden input view.
        while IME_BRIDGE && let Some(text) = read_string(&self.android, "pollTyped").filter(|t| !t.is_empty()) {
            raw.events.push(egui::Event::Text(text));
        }
        // A picture the keyboard handed over (from its clipboard strip): insert it.
        if IME_BRIDGE
            && let Some(path) = read_string(&self.android, "pollPicture").filter(|p| !p.is_empty())
            && let Ok(bytes) = std::fs::read(path)
            && !bytes.is_empty()
        {
            let data = wordcraft_engine::cmd::insert::base64_encode(&bytes);
            if let Err(error) = self.word.run("insert.picture", serde_json::json!({ "data": data })) {
                log::warn!("insert picture from keyboard: {error}");
            }
        }
        self.word.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.word.ui(ui);
        open_links(ui.ctx(), &self.android);
        bridge_clipboard(ui.ctx(), &self.android);
        self.show_update_offer(ui.ctx());
        // Tell the hidden input view when the keyboard is wanted, so the keyboard talks to the app directly.
        let wants = IME_BRIDGE && ui.ctx().output(|o| o.ime.is_some());
        if wants != self.ime_wanted {
            log::info!("text input wanted: {wants}");
            self.ime_wanted = wants;
            show_keyboard(&self.android, wants);
        }
        if wants {
            // Pasted text comes from Java, which cannot wake us: look often while the keyboard is up.
            ui.ctx().request_repaint_after(Duration::from_millis(100));
        }
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

/// Ask the Java activity for the next document opened from another app (a path, or nothing).
fn poll_open(app: &AndroidApp) -> Option<String> {
    let path = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })?;
    (!path.is_empty()).then_some(path)
}

/// Show Android's file picker. `false` means it could not be opened.
fn start_pick(app: &AndroidApp, save: bool, name: &str, purpose: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        let purpose = env.new_string(purpose)?;
        env.call_method(
            activity,
            "startPick",
            "(ZLjava/lang/String;Ljava/lang/String;)V",
            &[JValue::Bool(u8::from(save)), JValue::from(&name), JValue::from(&purpose)],
        )?;
        Ok(())
    })
    .is_some()
}

/// The picker's answer once it has closed: the path to open or save to, or cancelled.
fn poll_pick(app: &AndroidApp) -> Option<FileDialogAnswer> {
    let answer = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollPick", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let answer: String = env.get_string(&text)?.into();
        Ok(answer)
    })?;
    if answer.is_empty() {
        return None;
    }
    // The paths picked, one per line; nothing at all means the dialog was cancelled.
    Some(Ok(answer.strip_prefix("OK\n").map(|paths| paths.split('\n').filter(|p| !p.is_empty()).map(str::to_string).collect()).unwrap_or_default()))
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

/// The text on Android's clipboard, if any.
fn clipboard_text(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardText").filter(|text| !text.is_empty())
}

/// The formatted (HTML) copy on Android's clipboard, if another app put one there.
fn clipboard_html(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardHtml").filter(|html| !html.is_empty())
}

/// A picture on Android's clipboard, as the file Java saved it in.
fn clipboard_picture(app: &AndroidApp) -> Option<ClipboardPicture> {
    let path = read_string(app, "clipboardImagePath").filter(|p| !p.is_empty())?;
    let bytes = std::fs::read(path).ok()?;
    (!bytes.is_empty()).then_some(ClipboardPicture::Encoded(bytes))
}

/// What kinds of things are on Android's clipboard (for "nothing to paste" messages).
fn clipboard_formats(app: &AndroidApp) -> Vec<String> {
    read_string(app, "clipboardFormats").map(|s| s.lines().filter(|l| !l.is_empty()).map(str::to_string).collect()).unwrap_or_default()
}

/// Put text (and, if given, its HTML) on Android's clipboard.
fn set_clipboard(app: &AndroidApp, text: &str, html: Option<&str>) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(text)?;
        let html = env.new_string(html.unwrap_or(""))?;
        env.call_method(activity, "setClipboard", "(Ljava/lang/String;Ljava/lang/String;)V", &[JValue::from(&text), JValue::from(&html)])?;
        Ok(())
    })
    .is_some()
}

/// What WordCraft copies (egui's "copy text" requests) goes on Android's clipboard for other apps.
fn bridge_clipboard(ctx: &egui::Context, app: &AndroidApp) {
    let formatted_just_now = HTML_COPIED.lock().ok().and_then(|at| *at).is_some_and(|at| at.elapsed() < Duration::from_millis(1500));
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::CopyText(text) => {
                if !formatted_just_now {
                    set_clipboard(app, text, None);
                }
                false
            }
            _ => true,
        });
    });
}

/// Ask the Java activity to look up the newest release of `repo` (the answer comes by `poll_update`).
fn start_update_check(app: &AndroidApp, repo: &str) {
    with_activity(app, |env, activity| {
        let repo = env.new_string(repo)?;
        env.call_method(activity, "startUpdateCheck", "(Ljava/lang/String;)V", &[JValue::from(&repo)])?;
        Ok(())
    });
}

/// The answer of the update check: "OK" with the tag, page and APK address on lines, or "NONE" when it failed.
fn poll_update(app: &AndroidApp) -> Option<String> {
    read_string(app, "pollUpdate").filter(|reply| !reply.is_empty())
}

/// Show or hide the on-screen keyboard, connected to the hidden input view.
fn show_keyboard(app: &AndroidApp, show: bool) {
    with_activity(app, |env, activity| {
        env.call_method(activity, "showKeyboard", "(Z)V", &[JValue::Bool(u8::from(show))])?;
        Ok(())
    });
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.hyperlink` and the app's own "open URL" requests end up as egui commands; open them here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                if open.url == "android-app://share-log" {
                    with_activity(app, |env, activity| {
                        env.call_method(activity, "shareLog", "()V", &[])?;
                        Ok(())
                    });
                } else {
                    open_link(app, &open.url);
                }
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("WordCraft").with_max_level(log::LevelFilter::Info));
    if std::env::var_os("HOME").is_none() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe { std::env::set_var("HOME", "/storage/emulated/0") };
    }
    let private = app.internal_data_path();
    if let Some(dir) = &private {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe {
            std::env::set_var("HOME", dir);
            std::env::set_var("XDG_CONFIG_HOME", dir.join("config"));
            std::env::set_var("XDG_DATA_HOME", dir.join("data"));
            std::env::set_var("XDG_CACHE_HOME", dir.join("cache"));
        }
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "WordCraft",
        options,
        Box::new(move |cc| {
            let region = wordcraft_ui_egui::i18n::system_region();
            let doc = wordcraft_engine::blank_document(&region);
            let mut session = Session::new(doc);
            session.system_region = region;
            // Android's own picker; if it can't be shown, answer with an error and the app uses its own browser.
            let ctx = cc.egui_ctx.clone();
            let picker = android.clone();
            let file_dialog: Box<dyn Fn(FileDialogRequest) -> mpsc::Receiver<FileDialogAnswer>> = Box::new(move |request| {
                let (answer, rx) = mpsc::channel();
                let (save, name, purpose) = match &request {
                    FileDialogRequest::Open { purpose } => (false, String::new(), purpose.clone()),
                    // Several files: the Java side sees the "multi:" prefix and lets the user pick more than one.
                    FileDialogRequest::OpenMany { purpose } => (false, String::new(), format!("multi:{purpose}")),
                    FileDialogRequest::Save { name, .. } => (true, name.clone(), String::new()),
                };
                let shown = start_pick(&picker, save, &name, &purpose);
                match (shown, EXTERNAL.lock()) {
                    (true, Ok(mut waiting)) => *waiting = Some(answer),
                    _ => {
                        let _ = answer.send(Err("no system file dialog on Android".to_string()));
                    }
                }
                ctx.request_repaint();
                rx
            });
            let (reader, html_reader, writer) = (android.clone(), android.clone(), android.clone());
            let (picture_reader, formats_reader) = (android.clone(), android.clone());
            let services = Services {
                file_dialog: Some(file_dialog),
                // Paste from the ribbon and the context menu reads Android's clipboard.
                clipboard_text: Some(Box::new(move || clipboard_text(&reader))),
                clipboard_html: Some(Box::new(move || clipboard_html(&html_reader))),
                clipboard_picture: Some(Box::new(move || clipboard_picture(&picture_reader))),
                clipboard_formats: Some(Box::new(move || clipboard_formats(&formats_reader))),
                // (html, text, and for a copied equation its MathML: Android has no place for that, so it is not kept)
                set_clipboard_html: Some(Box::new(move |html: &str, text: &str, _mathml: &str| {
                    if let Ok(mut at) = HTML_COPIED.lock() {
                        *at = Some(Instant::now());
                    }
                    set_clipboard(&writer, text, Some(html))
                })),
                ..Default::default()
            };
            let mut word = WordApp::new(session, services);
            // Interface settings and recent documents saved by an earlier run.
            let prefs_path = private.as_ref().map(|dir| dir.join("config").join("ui.json"));
            let mut prefs_ok = prefs_path.is_some();
            if let Some(path) = &prefs_path
                && let Ok(bytes) = std::fs::read(path)
            {
                match UiState::from_json(&bytes) {
                    Some(ui) => word.apply_prefs(ui),
                    None => {
                        // Keep the unreadable file aside and start fresh, so settings are remembered from now on.
                        log::warn!("settings in {} could not be read; they were set aside", path.display());
                        let _ = std::fs::rename(path, path.with_extension("json.bad"));
                    }
                }
            }
            // Autosaved copies of unsaved documents, offered again after a crash or a swiped-away app.
            if let Some(dir) = &private {
                let wake = cc.egui_ctx.clone();
                if let Err(error) = word.session.enable_recovery(dir.join("config").join("recovery"), Arc::new(move || wake.request_repaint())) {
                    log::warn!("local recovery unavailable: {error}");
                }
            }
            word.start_screen();
            let update_file = private.as_ref().map(|dir| dir.join("config").join("update.json"));
            let update_choice = update_file.as_deref().map(load_update_choice).unwrap_or_default();
            Ok(Box::new(App {
                word,
                android,
                prefs_path,
                saved: Vec::new(),
                last_check: Instant::now(),
                prefs_ok,
                launched: Instant::now(),
                update_started: false,
                update_choice,
                update_file,
                update_offer: None,
                touch: Touch::default(),
                last_autosave: Instant::now(),
                ime_wanted: false,
                last_theme: String::new(),
            }))
        }),
    );
    if let Err(error) = result {
        log::error!("WordCraft failed to start: {error}");
    }
}

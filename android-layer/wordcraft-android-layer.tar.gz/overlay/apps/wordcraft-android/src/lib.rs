//! WordCraft for Android: runs the shared egui UI (`wordcraft-ui-egui`) inside a NativeActivity.
//!
//! First version: no preferences file, no system file dialogs (the app's built-in file browser is
//! used) and no print support. Everything else is the desktop `WordApp`.
#![cfg(target_os = "android")]

use android_activity::AndroidApp;
use wordcraft_engine::Session;
use wordcraft_ui_egui::{Services, WordApp};

struct App(WordApp);

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.0.logic(ctx);
    }
    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.0.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.0.ui(ui);
    }
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("WordCraft").with_max_level(log::LevelFilter::Info));
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "WordCraft",
        options,
        Box::new(|_cc| {
            let region = wordcraft_ui_egui::i18n::system_region();
            let doc = wordcraft_engine::blank_document(&region);
            let mut session = Session::new(doc);
            session.system_region = region;
            let mut app = WordApp::new(session, Services::default());
            app.start_screen();
            Ok(Box::new(App(app)))
        }),
    );
    if let Err(error) = result {
        log::error!("WordCraft failed to start: {error}");
    }
}

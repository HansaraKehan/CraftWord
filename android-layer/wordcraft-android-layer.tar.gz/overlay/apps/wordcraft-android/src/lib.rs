//! WordCraft for Android: runs the shared egui UI (`wordcraft-ui-egui`) inside a NativeActivity.
//!
//! - File ▸ Open / Save As use the app's built-in file browser (needs "All files access").
//! - Files opened from other apps ("Open with" WordCraft) arrive through the Java activity, which
//!   copies them to a folder and hands the path over; `poll_open` picks it up on every few frames.
//! - Not yet: preferences file, printing.
#![cfg(target_os = "android")]

use std::sync::mpsc;
use std::time::Duration;

use android_activity::AndroidApp;
use jni::{
    JavaVM,
    objects::{JObject, JString},
};
use wordcraft_engine::Session;
use wordcraft_ui_egui::{FileDialogAnswer, FileDialogRequest, Services, WordApp};

struct App {
    word: WordApp,
    android: AndroidApp,
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android)
            && let Err(error) = self.word.run("file.open", serde_json::json!({ "path": path }))
        {
            log::warn!("open {path}: {error}");
        }
        self.word.logic(ctx);
        // Wake now and then to see a document another app handed us.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.word.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.word.ui(ui);
    }
}

/// Ask the Java activity for the next document opened from another app (a path, or nothing).
#[allow(unsafe_code)]
fn poll_open(app: &AndroidApp) -> Option<String> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    let result = env.with_local_frame(8, |env| -> Result<String, jni::errors::Error> {
        let value = env.call_method(&activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    });
    match result {
        Ok(path) if !path.is_empty() => Some(path),
        Ok(_) => None,
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("WordCraft").with_max_level(log::LevelFilter::Info));
    if std::env::var_os("HOME").is_none() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe { std::env::set_var("HOME", "/storage/emulated/0") };
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "WordCraft",
        options,
        Box::new(move |cc| {
            let region = wordcraft_ui_egui::i18n::system_region();
            let doc = wordcraft_engine::blank_document(&region);
            let mut session = Session::new(doc);
            session.system_region = region;
            // No system dialog yet: answering with an error makes the app show its own file browser.
            let ctx = cc.egui_ctx.clone();
            let file_dialog: Box<dyn Fn(FileDialogRequest) -> mpsc::Receiver<FileDialogAnswer>> = Box::new(move |_request| {
                let (answer, rx) = mpsc::channel();
                let _ = answer.send(Err("no system file dialog on Android".to_string()));
                ctx.request_repaint();
                rx
            });
            let services = Services { file_dialog: Some(file_dialog), ..Default::default() };
            let mut word = WordApp::new(session, services);
            word.start_screen();
            Ok(Box::new(App { word, android }))
        }),
    );
    if let Err(error) = result {
        log::error!("WordCraft failed to start: {error}");
    }
}

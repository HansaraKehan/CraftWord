//! WordCraft for Android: runs the shared egui UI (`wordcraft-ui-egui`) inside a NativeActivity.
//!
//! - File ▸ Open / Save As use Android's own file picker (no storage permission needed): the Java
//!   activity copies the chosen document to a private folder and writes later saves back to it. If the
//!   picker can't be shown, the built-in file browser is used (it needs "All files access").
//! - Files opened from other apps ("Open with" WordCraft) arrive through the Java activity, which
//!   copies them to a folder and hands the path over; `poll_open` picks it up on every few frames.
//! - Not yet: preferences file, printing.
#![cfg(target_os = "android")]

use std::sync::{Mutex, mpsc};
use std::time::Duration;

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use wordcraft_engine::Session;
use wordcraft_ui_egui::{FileDialogAnswer, FileDialogRequest, Services, WordApp};

/// The answer channel of a file dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<FileDialogAnswer>>> = Mutex::new(None);

struct App {
    word: WordApp,
    android: AndroidApp,
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android)
            && let Err(error) = self.word.run("file.open", serde_json::json!({ "path": path }))
        {
            log::warn!("open {path}: {error}");
        }
        if let Some(answer) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(answer);
        }
        self.word.logic(ctx);
        // Wake now and then to see a document another app handed us.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.word.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.word.ui(ui);
        open_links(ui.ctx(), &self.android);
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

/// Ask the Java activity for the next document opened from another app (a path, or nothing).
fn poll_open(app: &AndroidApp) -> Option<String> {
    let path = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })?;
    (!path.is_empty()).then_some(path)
}

/// Show Android's file picker. `false` means it could not be opened.
fn start_pick(app: &AndroidApp, save: bool, name: &str, purpose: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        let purpose = env.new_string(purpose)?;
        env.call_method(
            activity,
            "startPick",
            "(ZLjava/lang/String;Ljava/lang/String;)V",
            &[JValue::Bool(u8::from(save)), JValue::from(&name), JValue::from(&purpose)],
        )?;
        Ok(())
    })
    .is_some()
}

/// The picker's answer once it has closed: the path to open or save to, or cancelled.
fn poll_pick(app: &AndroidApp) -> Option<FileDialogAnswer> {
    let answer = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollPick", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let answer: String = env.get_string(&text)?.into();
        Ok(answer)
    })?;
    if answer.is_empty() {
        return None;
    }
    Some(Ok(answer.strip_prefix("OK\n").map(str::to_string)))
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.hyperlink` and the app's own "open URL" requests end up as egui commands; open them here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("WordCraft").with_max_level(log::LevelFilter::Info));
    if std::env::var_os("HOME").is_none() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe { std::env::set_var("HOME", "/storage/emulated/0") };
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "WordCraft",
        options,
        Box::new(move |cc| {
            let region = wordcraft_ui_egui::i18n::system_region();
            let doc = wordcraft_engine::blank_document(&region);
            let mut session = Session::new(doc);
            session.system_region = region;
            // Android's own picker; if it can't be shown, answer with an error and the app uses its own browser.
            let ctx = cc.egui_ctx.clone();
            let picker = android.clone();
            let file_dialog: Box<dyn Fn(FileDialogRequest) -> mpsc::Receiver<FileDialogAnswer>> = Box::new(move |request| {
                let (answer, rx) = mpsc::channel();
                let (save, name, purpose) = match &request {
                    FileDialogRequest::Open { purpose } => (false, String::new(), purpose.clone()),
                    FileDialogRequest::Save { name } => (true, name.clone(), String::new()),
                };
                let shown = start_pick(&picker, save, &name, &purpose);
                match (shown, EXTERNAL.lock()) {
                    (true, Ok(mut waiting)) => *waiting = Some(answer),
                    _ => {
                        let _ = answer.send(Err("no system file dialog on Android".to_string()));
                    }
                }
                ctx.request_repaint();
                rx
            });
            let services = Services { file_dialog: Some(file_dialog), ..Default::default() };
            let mut word = WordApp::new(session, services);
            word.start_screen();
            Ok(Box::new(App { word, android }))
        }),
    );
    if let Err(error) = result {
        log::error!("WordCraft failed to start: {error}");
    }
}

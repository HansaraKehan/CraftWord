//! WordCraft for Android: runs the shared egui UI (`wordcraft-ui-egui`) inside a NativeActivity.
//!
//! - File ▸ Open / Save As use Android's own file picker (no storage permission needed): the Java
//!   activity copies the chosen document to a private folder and writes later saves back to it. If the
//!   picker can't be shown, the built-in file browser is used (it needs "All files access").
//! - Files opened from other apps ("Open with" WordCraft) arrive through the Java activity, which
//!   copies them to a folder and hands the path over; `poll_open` picks it up on every few frames.
//! - Not yet: preferences file, printing.
#![cfg(target_os = "android")]

use std::path::PathBuf;
use std::sync::{Arc, Mutex, mpsc};
use std::time::{Duration, Instant};

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use wordcraft_engine::Session;
use wordcraft_ui_egui::paste_picture::ClipboardPicture;
use wordcraft_ui_egui::{FileDialogAnswer, FileDialogRequest, Services, UiState, WordApp};

/// The answer channel of a file dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<FileDialogAnswer>>> = Mutex::new(None);

/// How long a finger must stay still before it selects instead of scrolling.
const HOLD: f64 = 0.45;
/// How far (points) a finger may wander and still count as held.
const SLOP: f32 = 10.0;

#[derive(PartialEq)]
enum Mode {
    /// Down, not yet moved or held: could still be a tap, a scroll or a selection.
    Pending,
    /// Moving: the page scrolls with the finger.
    Scroll,
    /// Held still, then dragged: a real press, so the page selects text.
    Select,
}

/// One finger on the page, followed from touch-down.
struct Gesture {
    id: egui::TouchId,
    start: egui::Pos2,
    last: egui::Pos2,
    started_at: f64,
    mode: Mode,
    /// Whether holding still may start a text selection (the tool selects text).
    hold_selects: bool,
}

#[derive(Default)]
struct Touch {
    /// Fingers on the screen.
    fingers: u32,
    gesture: Option<Gesture>,
    /// The pointer events egui-winit makes from a finger that is scrolling are dropped, up to its `PointerGone`.
    drop_pointer: bool,
    /// Where a held finger lifted: the context menu (Copy, Highlight…) opens there.
    menu_at: Option<egui::Pos2>,
    /// A finger tapped the document this frame (not a swipe or a hold).
    tapped: bool,
    /// Events held back for the next frames, so a press and its release never share a frame (the page view
    /// counts clicks from the press, as it would for a real tap).
    later: std::collections::VecDeque<Vec<egui::Event>>,
}

fn wheel(delta: egui::Vec2, phase: egui::TouchPhase, modifiers: egui::Modifiers) -> egui::Event {
    egui::Event::MouseWheel { unit: egui::MouseWheelUnit::Point, delta, phase, modifiers, source: egui::MouseWheelSource::Unknown }
}

fn press(pos: egui::Pos2, button: egui::PointerButton, modifiers: egui::Modifiers) -> [egui::Event; 2] {
    [egui::Event::PointerMoved(pos), egui::Event::PointerButton { pos, button, pressed: true, modifiers }]
}

fn release(pos: egui::Pos2, button: egui::PointerButton, modifiers: egui::Modifiers) -> egui::Event {
    egui::Event::PointerButton { pos, button, pressed: false, modifiers }
}

/// When the last formatted copy was put on the Android clipboard: egui also reports the plain text of
/// that copy, which must not replace it.
static HTML_COPIED: Mutex<Option<Instant>> = Mutex::new(None);

/// The keyboard's clipboard strip (and pasted words) reach the app only through a real text connection: the Java
/// side wraps the app's view in a layout that owns it (see `ImeLayout`), and this side shows and hides the keyboard.
const IME_BRIDGE: bool = true;

/// The repository this build came from (set by the workflow), whose Releases hold newer builds.
const REPO: &str = match option_env!("GITHUB_REPOSITORY") {
    Some(repo) => repo,
    None => "HansaraKehan/CraftWord",
};

/// A newer build of this app than the installed one.
struct UpdateOffer {
    tag: String,
    installed: String,
    page: String,
    apk: String,
}

/// What the user told the update check: a version to leave alone, and a time before which not to ask again.
#[derive(Default)]
struct UpdateChoice {
    skipped: String,
    remind_after: u64,
}

/// A button big enough for a finger.
fn touch_button(text: &str) -> egui::Button<'_> {
    egui::Button::new(text).min_size(egui::vec2(120.0, 44.0))
}

fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn load_update_choice(path: &std::path::Path) -> UpdateChoice {
    let value: serde_json::Value = std::fs::read(path).ok().and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_default();
    UpdateChoice {
        skipped: value.get("skipped").and_then(|v| v.as_str()).unwrap_or_default().to_string(),
        remind_after: value.get("remind_after").and_then(|v| v.as_u64()).unwrap_or(0),
    }
}

struct App {
    word: WordApp,
    android: AndroidApp,
    /// `<private>/config/ui.json`, the last bytes written to it, when we last looked, and whether it is
    /// safe to overwrite (it was missing or read fine).
    prefs_path: Option<PathBuf>,
    saved: Vec<u8>,
    last_check: Instant,
    prefs_ok: bool,
    /// Checking for a newer build: when the app started, whether the check was sent, the choice made earlier
    /// (kept in `update.json`), and the offer to show.
    launched: Instant,
    update_started: bool,
    update_choice: UpdateChoice,
    update_file: Option<PathBuf>,
    update_offer: Option<UpdateOffer>,
    touch: Touch,
    last_autosave: Instant,
    /// The on-screen keyboard is wanted by the app; and the theme last written (a change is saved at once).
    ime_wanted: bool,
    last_theme: String,
    /// The first-run screen (welcome, and why file access is needed), the file that remembers "Not now",
    /// and when file access was last looked at.
    welcome: bool,
    welcome_skip: Option<PathBuf>,
    access_checked: Instant,
    /// The system's light/dark choice, when it was last read.
    dark: Option<bool>,
    dark_read: Instant,
    /// The file name given to a new document from its text, so it can be renamed as the first words change.
    auto: Option<AutoName>,
    rename_checked: Instant,
}

/// A document that got its file name from what it says. `title` is what the name was made from;
/// `seen` is the first words now, and `seen_at` when they last changed (a rename waits for them to settle).
struct AutoName {
    path: PathBuf,
    stamp: String,
    title: String,
    seen: String,
    seen_at: Instant,
}

impl App {
    /// On the page: a finger that moves scrolls it (as a trackpad swipe would), a tap clicks, and, where text
    /// can be selected, a finger held still starts a selection that the drag that follows extends. Everywhere
    /// else, and for a mouse or pen, input is left alone. The page view says where it is
    /// (`android.page_rect`: its area, and whether holding selects), for the Hand and text-selecting tools.
    fn filter_touch(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        let now = raw.time.unwrap_or(0.0);
        let page = ctx.data(|d| d.get_temp::<Option<(egui::Rect, bool)>>(egui::Id::new("android.page_rect"))).flatten();
        let modifiers = egui::Modifiers::NONE;
        let t = &mut self.touch;
        let mut out = Vec::with_capacity(raw.events.len() + 4);
        let mut tap: Option<egui::Pos2> = None;
        // The second half of a tap or a menu click made in an earlier frame.
        if let Some(batch) = t.later.pop_front() {
            out.extend(batch);
            if !t.later.is_empty() {
                ctx.request_repaint();
            }
        }
        for event in std::mem::take(&mut raw.events) {
            if let egui::Event::Touch { id, phase, pos, .. } = &event {
                match phase {
                    egui::TouchPhase::Start => {
                        t.fingers += 1;
                        // A second finger is a pinch: never a scroll or a selection.
                        t.gesture = (t.fingers == 1)
                            .then(|| page.filter(|(rect, _)| rect.contains(*pos)))
                            .flatten()
                            .map(|(_, hold_selects)| Gesture { id: *id, start: *pos, last: *pos, started_at: now, mode: Mode::Pending, hold_selects });
                        if t.fingers > 1 {
                            // A pinch needs a pointer position (the page only zooms under the pointer).
                            t.drop_pointer = false;
                            out.push(egui::Event::PointerMoved(*pos));
                        } else {
                            t.drop_pointer = t.gesture.is_some();
                        }
                    }
                    egui::TouchPhase::Move => {
                        if let Some(g) = t.gesture.as_mut()
                            && g.id == *id
                        {
                            match g.mode {
                                Mode::Pending if pos.distance(g.start) > SLOP => {
                                    g.mode = Mode::Scroll;
                                    // egui scrolls the area under the pointer: say where the finger is.
                                    out.push(egui::Event::PointerMoved(*pos));
                                    out.push(wheel(*pos - g.start, egui::TouchPhase::Start, modifiers));
                                    g.last = *pos;
                                }
                                Mode::Scroll => {
                                    out.push(egui::Event::PointerMoved(*pos));
                                    out.push(wheel(*pos - g.last, egui::TouchPhase::Move, modifiers));
                                    g.last = *pos;
                                }
                                _ => {}
                            }
                        }
                    }
                    egui::TouchPhase::End | egui::TouchPhase::Cancel => {
                        t.fingers = t.fingers.saturating_sub(1);
                        if let Some(g) = t.gesture.take_if(|g| g.id == *id) {
                            let ended = *phase == egui::TouchPhase::End;
                            match g.mode {
                                Mode::Pending if ended => {
                                    // A tap: press now, release in the next frame.
                                    out.extend(press(*pos, egui::PointerButton::Primary, modifiers));
                                    tap = Some(*pos);
                                    t.tapped = true;
                                    t.later.push_back(vec![release(*pos, egui::PointerButton::Primary, modifiers), egui::Event::PointerGone]);
                                    ctx.request_repaint();
                                }
                                Mode::Scroll => {
                                    out.push(wheel(egui::Vec2::ZERO, egui::TouchPhase::End, modifiers));
                                    out.push(egui::Event::PointerGone);
                                }
                                Mode::Select if ended => t.menu_at = Some(*pos),
                                _ => {}
                            }
                        }
                    }
                }
                // Touch events always go on: egui measures pinch zoom from them.
                out.push(event);
                continue;
            }
            if matches!(event, egui::Event::PointerGone) {
                // The finger is up. A held-then-selected text opens its menu (Copy, Highlight…) where it lifted.
                if let Some(pos) = t.menu_at.take() {
                    t.drop_pointer = false;
                    out.push(event);
                    out.extend(press(pos, egui::PointerButton::Secondary, modifiers));
                    t.later.push_back(vec![release(pos, egui::PointerButton::Secondary, modifiers)]);
                    ctx.request_repaint();
                    continue;
                }
                if t.drop_pointer && t.gesture.is_none() {
                    t.drop_pointer = false;
                    continue;
                }
            }
            let pointer_event = matches!(event, egui::Event::PointerMoved(_) | egui::Event::PointerButton { .. } | egui::Event::PointerGone);
            if pointer_event && t.drop_pointer && t.gesture.as_ref().is_none_or(|g| g.mode != Mode::Select) {
                continue;
            }
            out.push(event);
        }
        // Held still long enough: press where the finger went down, and let the drag extend the selection.
        if let Some(g) = t.gesture.as_mut()
            && g.mode == Mode::Pending
            && g.hold_selects
            && now - g.started_at >= HOLD
        {
            g.mode = Mode::Select;
            t.drop_pointer = false;
            out.extend(press(g.start, egui::PointerButton::Primary, modifiers));
        }
        if t.gesture.as_ref().is_some_and(|g| g.mode == Mode::Pending && g.hold_selects) {
            // No event arrives while the finger rests: wake up to notice the hold.
            ctx.request_repaint_after(Duration::from_millis(100));
        }
        raw.events = out;
        // Where a tap landed this frame (the page view clears its text selection there).
        ctx.data_mut(|d| d.insert_temp(egui::Id::new("android.tap_pos"), tap));
    }

    /// Android never closes the app politely, so the desktop's "save when quitting" never runs: write the
    /// interface settings and recent documents a few seconds after they change instead.
    fn remember_update_choice(&self) {
        let Some(path) = &self.update_file else { return };
        let value = serde_json::json!({ "skipped": self.update_choice.skipped, "remind_after": self.update_choice.remind_after });
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        let _ = std::fs::write(path, value.to_string());
    }

    /// A few seconds after start, ask GitHub for the newest release of this app, and offer it if it is not
    /// the installed one, unless the user skipped that version or asked to be reminded later.
    fn check_for_updates(&mut self) {
        if !self.update_started && self.launched.elapsed() > Duration::from_secs(5) {
            self.update_started = true;
            if now_secs() >= self.update_choice.remind_after {
                start_update_check(&self.android, REPO);
            }
        }
        if let Some(reply) = poll_update(&self.android)
            && let Some(rest) = reply.strip_prefix("OK\n")
        {
            let mut lines = rest.split('\n');
            let (tag, page, apk) = (lines.next().unwrap_or(""), lines.next().unwrap_or(""), lines.next().unwrap_or(""));
            let installed = read_string(&self.android, "installedVersion").unwrap_or_default();
            if !tag.is_empty() && tag != installed && tag != self.update_choice.skipped {
                self.update_offer = Some(UpdateOffer { tag: tag.to_string(), installed, page: page.to_string(), apk: apk.to_string() });
            }
        }
    }

    fn show_update_offer(&mut self, ctx: &egui::Context) {
        let Some(offer) = &self.update_offer else { return };
        enum Choice {
            Download,
            Later,
            Skip,
        }
        let mut choice = None;
        egui::Window::new("A new version is available")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
            .show(ctx, |ui| {
                ui.label("A newer build of WordCraft for Android is ready to download.");
                ui.add_space(4.0);
                ui.label(format!("Installed: {}", if offer.installed.is_empty() { "unknown" } else { &offer.installed }));
                ui.label(format!("New: {}", offer.tag));
                ui.add_space(8.0);
                ui.horizontal_wrapped(|ui| {
                    if ui.add(touch_button("Download")).clicked() {
                        choice = Some(Choice::Download);
                    }
                    if ui.add(touch_button("Remind me later")).clicked() {
                        choice = Some(Choice::Later);
                    }
                    if ui.add(touch_button("Skip this version")).clicked() {
                        choice = Some(Choice::Skip);
                    }
                });
            });
        let Some(choice) = choice else { return };
        let Some(offer) = self.update_offer.take() else { return };
        match choice {
            Choice::Download => {
                // The APK itself when the release has one, else the release page; ask again tomorrow if it was not installed.
                open_link(&self.android, if offer.apk.is_empty() { &offer.page } else { &offer.apk });
                self.update_choice.remind_after = now_secs() + 24 * 3600;
            }
            Choice::Later => self.update_choice.remind_after = now_secs() + 24 * 3600,
            Choice::Skip => self.update_choice.skipped = offer.tag,
        }
        self.remember_update_choice();
    }

    /// AutoSave is on by default but only covers a document that has a file. So a new document gets a file of its
    /// own the moment it has changes (no name asked for; `Save As` still renames it), and a document that was
    /// opened is saved once when first edited, which is what makes AutoSave keep writing to it.
    ///
    /// The file is named from what the document says plus the date and time ("Meeting notes - 2026-10-31 05-30"),
    /// so it is easy to find. Once the first words stop changing for a few seconds, the file takes their new name.
    fn keep_autosave_on(&mut self) {
        if self.last_autosave.elapsed() < Duration::from_secs(2) || !self.word.autosave || !self.word.session.dirty {
            return;
        }
        self.last_autosave = Instant::now();
        match self.word.session.path.clone() {
            None => {
                let title = self.first_words();
                let stamp = read_string(&self.android, "nowStamp").unwrap_or_default();
                if let Some(path) = document_path(&self.android, &title, &stamp, "") {
                    if self.word.run("file.saveAs", serde_json::json!({ "path": path })).is_ok() {
                        self.auto = Some(AutoName {
                            path: PathBuf::from(&path),
                            stamp,
                            seen: title.clone(),
                            title,
                            seen_at: Instant::now(),
                        });
                    }
                }
            }
            Some(path) => {
                if !self.word.saved_here() && wordcraft_ui_egui::keeps_everything(&path.to_string_lossy()) {
                    let _ = self.word.run("file.save", serde_json::json!({}));
                }
            }
        }
    }

    /// Every second or so, see whether the document's file should take a new name from its first words.
    fn maybe_rename(&mut self) {
        if self.auto.is_none() || self.rename_checked.elapsed() < Duration::from_secs(1) {
            return;
        }
        self.rename_checked = Instant::now();
        match self.word.session.path.clone() {
            Some(path) => self.rename_from_text(&path),
            None => self.auto = None,
        }
    }

    /// The first line of the document with something in it, the start of its file name.
    fn first_words(&self) -> String {
        let text = self.word.session.doc.plain_text(wordcraft_engine::doc::StoryRef::Body);
        text.lines().map(str::trim).find(|l| !l.is_empty()).map(|l| l.chars().take(60).collect()).unwrap_or_default()
    }

    /// Give a document whose file was named by the app the name its first words now suggest, once they have stopped
    /// changing. A document the person saved under a name of their own (or opened) is never renamed.
    fn rename_from_text(&mut self, current: &std::path::Path) {
        let words = self.first_words();
        let Some(auto) = self.auto.as_mut() else { return };
        if auto.path != current {
            self.auto = None;
            return;
        }
        if words != auto.seen {
            auto.seen = words;
            auto.seen_at = Instant::now();
            return;
        }
        if auto.seen == auto.title || auto.seen.is_empty() || auto.seen_at.elapsed() < Duration::from_secs(5) {
            return;
        }
        let (title, stamp, old) = (auto.seen.clone(), auto.stamp.clone(), auto.path.clone());
        let Some(path) = document_path(&self.android, &title, &stamp, &old.to_string_lossy()) else { return };
        if PathBuf::from(&path) == old {
            if let Some(auto) = self.auto.as_mut() {
                auto.title = title;
            }
            return;
        }
        if self.word.run("file.saveAs", serde_json::json!({ "path": path })).is_ok() {
            // The renamed copy is saved; the file with the old name is no longer needed.
            let _ = std::fs::remove_file(&old);
            if let Some(auto) = self.auto.as_mut() {
                auto.path = PathBuf::from(&path);
                auto.title = title;
            }
        }
    }

    /// Notice when file access has been allowed (in Android's settings, after the welcome screen sent the person there):
    /// the welcome screen closes, and documents kept inside the app until now move to Documents/WordCraft.
    fn watch_file_access(&mut self) {
        if !self.welcome || self.access_checked.elapsed() < Duration::from_millis(600) {
            return;
        }
        self.access_checked = Instant::now();
        if files_access(&self.android) {
            self.welcome = false;
            move_private_documents(&self.android);
        }
    }

    /// First-run screen: what WordCraft is, and why it needs access to files. Nothing is asked of Android until the
    /// person presses the button.
    fn show_welcome(&mut self, ui: &mut egui::Ui) {
        use egui::{Color32, RichText, Vec2};
        let dark = self.word.ui_is_dark();
        let (bg, card, strong, weak, accent) = if dark {
            (Color32::from_rgb(22, 25, 31), Color32::from_rgb(35, 39, 48), Color32::from_rgb(240, 243, 248), Color32::from_rgb(166, 175, 190), Color32::from_rgb(86, 156, 240))
        } else {
            (Color32::from_rgb(238, 243, 251), Color32::WHITE, Color32::from_rgb(22, 32, 52), Color32::from_rgb(92, 104, 126), Color32::from_rgb(43, 87, 154))
        };
        ui.painter().rect_filled(ui.max_rect(), 0.0, bg);
        let (mut allow, mut later) = (false, false);
        egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
            ui.vertical_centered(|ui| {
                let width = ui.available_width().min(640.0) - 32.0;
                ui.add_space(20.0);
                let (art, _) = ui.allocate_exact_size(Vec2::new(width.min(380.0), 200.0), egui::Sense::hover());
                draw_clipart(ui.painter(), art, dark);
                ui.add_space(10.0);
                ui.label(RichText::new("Welcome to WordCraft for Android").size(30.0).strong().color(strong));
                ui.add_space(4.0);
                ui.label(RichText::new("Write, edit and open Word documents anywhere.").size(17.0).color(weak));
                ui.add_space(18.0);
                egui::Frame::NONE.fill(card).corner_radius(16).inner_margin(18).show(ui, |ui| {
                    ui.set_width(width - 36.0);
                    let rows = [
                        ("1", "Your documents stay yours", "They are saved in the Documents/WordCraft folder, so they are still there if you ever uninstall the app."),
                        ("2", "Easy to find", "Each file is named after what you wrote plus the date and time, for example \"Meeting notes - 2026-10-31 05-30\"."),
                        ("3", "One permission needed", "To save there and open files from other folders, WordCraft needs \"All files access\". Android will open a settings page: turn on the switch for WordCraft, then come back."),
                    ];
                    for (n, head, body) in rows {
                        ui.horizontal_top(|ui| {
                            let (dot, _) = ui.allocate_exact_size(Vec2::splat(38.0), egui::Sense::hover());
                            ui.painter().circle_filled(dot.center(), 19.0, accent);
                            ui.painter().text(dot.center(), egui::Align2::CENTER_CENTER, n, egui::FontId::proportional(19.0), Color32::WHITE);
                            ui.vertical(|ui| {
                                ui.set_max_width(width - 36.0 - 60.0);
                                ui.label(RichText::new(head).size(18.0).strong().color(strong));
                                ui.label(RichText::new(body).size(15.0).color(weak));
                            });
                        });
                        ui.add_space(10.0);
                    }
                });
                ui.add_space(18.0);
                if ui.add(egui::Button::new(RichText::new("Allow file access").size(19.0).strong().color(Color32::WHITE)).fill(accent).min_size(Vec2::new(width.min(360.0), 52.0))).clicked() {
                    allow = true;
                }
                ui.add_space(8.0);
                if ui.add(egui::Button::new(RichText::new("Not now").size(16.0).color(weak)).frame(false).min_size(Vec2::new(160.0, 40.0))).clicked() {
                    later = true;
                }
                ui.add_space(4.0);
                ui.label(RichText::new("Without it, documents stay inside the app and are removed when it is uninstalled.").size(13.0).color(weak));
                ui.add_space(24.0);
            });
        });
        if allow {
            request_files_access(&self.android);
        }
        if later {
            self.welcome = false;
            if let Some(file) = &self.welcome_skip {
                if let Some(dir) = file.parent() {
                    let _ = std::fs::create_dir_all(dir);
                }
                let _ = std::fs::write(file, b"skipped");
            }
        }
    }

    fn save_prefs(&mut self) {
        // A theme change is saved straight away; anything else within a few seconds.
        let theme = serde_json::to_string(&self.word.ui.theme).unwrap_or_default();
        let theme_changed = theme != self.last_theme;
        self.last_theme = theme;
        if !self.prefs_ok || (self.last_check.elapsed() < Duration::from_secs(4) && !theme_changed) {
            return;
        }
        self.last_check = Instant::now();
        let Some(path) = &self.prefs_path else { return };
        let Ok(bytes) = serde_json::to_vec_pretty(&self.word.prefs()) else { return };
        if bytes == self.saved {
            return;
        }
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        // Temporary file, then rename: an interrupted write leaves the previous settings in place.
        let tmp = path.with_extension("json.tmp");
        if std::fs::write(&tmp, &bytes).and_then(|()| std::fs::rename(&tmp, path)).is_ok() {
            self.saved = bytes;
        }
    }
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android)
            && let Err(error) = self.word.run("file.open", serde_json::json!({ "path": path }))
        {
            log::warn!("open {path}: {error}");
        }
        if let Some(answer) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(answer);
        }
        self.word.logic(ctx);
        self.save_prefs();
        self.check_for_updates();
        self.keep_autosave_on();
        self.maybe_rename();
        self.watch_file_access();
        // Wake now and then to see a document another app handed us.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        // Android's window library says nothing about the system's light/dark choice, so ask the activity
        // (about once a second, and straight away at start). "Use system setting" then follows it live.
        if self.dark.is_none() || self.dark_read.elapsed() >= Duration::from_secs(1) {
            self.dark_read = Instant::now();
            if let Some(dark) = system_is_dark(&self.android) {
                self.dark = Some(dark);
            }
        }
        if let Some(dark) = self.dark {
            raw.system_theme = Some(if dark { egui::Theme::Dark } else { egui::Theme::Light });
        }
        self.filter_touch(ctx, raw);
        if !raw.focused {
            // The app is going to the background, where Android may end it: save now.
            self.last_check = Instant::now().checked_sub(Duration::from_secs(10)).unwrap_or_else(Instant::now);
        }
        // Debug log: what a hardware keyboard's clipboard shortcuts turn into by the time they reach the app.
        for event in &raw.events {
            match event {
                egui::Event::Key { key: key @ (egui::Key::V | egui::Key::C | egui::Key::X | egui::Key::Paste), pressed, modifiers, .. } if modifiers.command || modifiers.ctrl => {
                    log::info!("shortcut key {key:?} pressed={pressed} modifiers={modifiers:?}");
                }
                egui::Event::Paste(text) => log::info!("paste event with {} characters", text.chars().count()),
                egui::Event::Copy => log::info!("copy event"),
                egui::Event::Cut => log::info!("cut event"),
                _ => {}
            }
        }
        // Ctrl+V: egui only knows what was copied inside the app; paste what is on Android's clipboard.
        for event in raw.events.iter_mut() {
            if let egui::Event::Paste(text) = event
                && let Some(system) = clipboard_text(&self.android)
            {
                *text = system;
            }
        }
        // The keyboard may have been put away (back gesture, another app): a tap in the document brings it back,
        // but a swipe or a scroll must not.
        if std::mem::take(&mut self.touch.tapped) && IME_BRIDGE && self.ime_wanted {
            show_keyboard(&self.android, true);
        }
        // Words and pastes from the on-screen keyboard (its clipboard strip) arrive through the hidden input view.
        while IME_BRIDGE && let Some(text) = read_string(&self.android, "pollTyped").filter(|t| !t.is_empty()) {
            // Whole pastes (long, or with line breaks) go through the paste path, which understands paragraphs;
            // typed text events do not carry line breaks.
            let long = text.contains('\n') || text.chars().count() > 40;
            log::info!("keyboard text: {} characters, as {}", text.chars().count(), if long { "a paste" } else { "typed text" });
            raw.events.push(if long { egui::Event::Paste(text) } else { egui::Event::Text(text) });
        }
        // A picture the keyboard handed over (from its clipboard strip): insert it.
        if IME_BRIDGE
            && let Some(path) = read_string(&self.android, "pollPicture").filter(|p| !p.is_empty())
            && let Ok(bytes) = std::fs::read(path)
            && !bytes.is_empty()
        {
            let data = wordcraft_engine::cmd::insert::base64_encode(&bytes);
            if let Err(error) = self.word.run("insert.picture", serde_json::json!({ "data": data })) {
                log::warn!("insert picture from keyboard: {error}");
            }
        }
        self.word.raw_input_hook(ctx, raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        if self.welcome {
            self.show_welcome(ui);
            return;
        }
        self.word.ui(ui);
        open_links(ui.ctx(), &self.android);
        bridge_clipboard(ui.ctx(), &self.android);
        self.show_update_offer(ui.ctx());
        // Tell the hidden input view when the keyboard is wanted, so the keyboard talks to the app directly.
        let wants = IME_BRIDGE && ui.ctx().output(|o| o.ime.is_some());
        if wants != self.ime_wanted {
            log::info!("text input wanted: {wants}");
            self.ime_wanted = wants;
            show_keyboard(&self.android, wants);
        }
        if wants {
            // Pasted text comes from Java, which cannot wake us: look often while the keyboard is up.
            ui.ctx().request_repaint_after(Duration::from_millis(100));
        }
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

/// Ask the Java activity for the next document opened from another app (a path, or nothing).
fn poll_open(app: &AndroidApp) -> Option<String> {
    let path = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })?;
    (!path.is_empty()).then_some(path)
}

/// Show Android's file picker. `false` means it could not be opened.
fn start_pick(app: &AndroidApp, save: bool, name: &str, purpose: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        let purpose = env.new_string(purpose)?;
        env.call_method(
            activity,
            "startPick",
            "(ZLjava/lang/String;Ljava/lang/String;)V",
            &[JValue::Bool(u8::from(save)), JValue::from(&name), JValue::from(&purpose)],
        )?;
        Ok(())
    })
    .is_some()
}

/// The picker's answer once it has closed: the path to open or save to, or cancelled.
fn poll_pick(app: &AndroidApp) -> Option<FileDialogAnswer> {
    let answer = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollPick", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let answer: String = env.get_string(&text)?.into();
        Ok(answer)
    })?;
    if answer.is_empty() {
        return None;
    }
    // The paths picked, one per line; nothing at all means the dialog was cancelled.
    Some(Ok(answer.strip_prefix("OK\n").map(|paths| paths.split('\n').filter(|p| !p.is_empty()).map(str::to_string).collect()).unwrap_or_default()))
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

/// Has the person allowed WordCraft to keep documents in shared storage (Documents/WordCraft)?
fn files_access(app: &AndroidApp) -> bool {
    read_string(app, "hasFilesAccess").is_some_and(|s| s == "1")
}

/// Open Android's page for allowing file access.
fn request_files_access(app: &AndroidApp) {
    let _ = with_activity(app, |env, activity| {
        env.call_method(activity, "requestFilesAccess", "()V", &[])?;
        Ok(())
    });
}

/// Move documents kept inside the app (before access was allowed) to Documents/WordCraft.
fn move_private_documents(app: &AndroidApp) {
    if let Some(moved) = read_string(app, "migrateDocuments")
        && moved != "0"
    {
        log::info!("moved {moved} document(s) to Documents/WordCraft");
    }
}

/// Is the system set to dark? `None` when it can't be asked.
fn system_is_dark(app: &AndroidApp) -> Option<bool> {
    match read_string(app, "systemTheme")?.as_str() {
        "dark" => Some(true),
        "light" => Some(false),
        _ => None,
    }
}

/// Where a document goes: named from its first words and the date (see `documentPathFor` in the activity).
fn document_path(app: &AndroidApp, title: &str, stamp: &str, current: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let (title, stamp, current) = (env.new_string(title)?, env.new_string(stamp)?, env.new_string(current)?);
        let value = env.call_method(
            activity,
            "documentPathFor",
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",
            &[JValue::from(&title), JValue::from(&stamp), JValue::from(&current)],
        )?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })
    .filter(|p| !p.is_empty())
}

/// The picture on the welcome screen, drawn in code: a document with a pencil, a folder marked safe, and sparkles.
fn draw_clipart(painter: &egui::Painter, rect: egui::Rect, dark: bool) {
    use egui::{Color32, Pos2, Rect, Shape, Stroke, vec2};
    let s = (rect.width() / 360.0).min(rect.height() / 200.0);
    let origin = rect.center() - vec2(180.0 * s, 100.0 * s);
    let p = |x: f32, y: f32| -> Pos2 { origin + vec2(x * s, y * s) };
    let r = |x0: f32, y0: f32, x1: f32, y1: f32| Rect::from_min_max(p(x0, y0), p(x1, y1));
    let blue = Color32::from_rgb(43, 87, 154);
    let sky = Color32::from_rgba_unmultiplied(64, 140, 230, if dark { 56 } else { 40 });
    // Soft background.
    painter.circle_filled(p(180.0, 104.0), 92.0 * s, sky);
    painter.circle_filled(p(300.0, 150.0), 30.0 * s, sky);
    painter.circle_filled(p(64.0, 30.0), 18.0 * s, sky);
    // Folder, with a green "safe" mark.
    painter.rect_filled(r(34.0, 84.0, 66.0, 100.0), 6.0 * s, Color32::from_rgb(235, 165, 40));
    painter.rect_filled(r(34.0, 92.0, 170.0, 172.0), 10.0 * s, Color32::from_rgb(244, 182, 52));
    painter.rect_filled(r(34.0, 104.0, 170.0, 172.0), 10.0 * s, Color32::from_rgb(255, 204, 82));
    // The page, with its shadow.
    painter.rect_filled(r(146.0, 26.0, 258.0, 168.0), 8.0 * s, Color32::from_black_alpha(if dark { 90 } else { 36 }));
    let sheet = Color32::from_rgb(250, 251, 253);
    let edge = Stroke::new(1.5 * s, Color32::from_rgb(196, 206, 222));
    painter.add(Shape::convex_polygon(vec![p(140.0, 18.0), p(222.0, 18.0), p(250.0, 46.0), p(250.0, 160.0), p(140.0, 160.0)], sheet, edge));
    painter.add(Shape::convex_polygon(vec![p(222.0, 18.0), p(250.0, 46.0), p(222.0, 46.0)], Color32::from_rgb(208, 220, 240), edge));
    painter.rect_filled(r(152.0, 32.0, 184.0, 62.0), 7.0 * s, blue);
    for y in [41.0, 47.0, 53.0] {
        painter.line_segment([p(159.0, y), p(177.0, y)], Stroke::new(2.6 * s, Color32::WHITE));
    }
    for (y, w, c) in [(74.0, 86.0, Color32::from_rgb(120, 150, 200)), (87.0, 70.0, Color32::from_rgb(204, 213, 228)), (99.0, 86.0, Color32::from_rgb(204, 213, 228)), (111.0, 58.0, Color32::from_rgb(204, 213, 228)), (123.0, 78.0, Color32::from_rgb(204, 213, 228)), (135.0, 44.0, Color32::from_rgb(204, 213, 228))] {
        painter.rect_filled(r(152.0, y, 152.0 + w, y + 6.0), 3.0 * s, c);
    }
    // A pencil writing on it, tip at the lower right of the page.
    let tip = p(238.0, 152.0);
    let d = vec2(0.766, -0.643);
    let n = vec2(0.643, 0.766);
    let pt = |x: f32, y: f32| -> Pos2 { tip + (d * x + n * y) * s };
    let quad = |x0: f32, x1: f32, y0: f32, y1: f32| vec![pt(x0, y0), pt(x1, y0), pt(x1, y1), pt(x0, y1)];
    painter.add(Shape::convex_polygon(vec![pt(0.0, 0.0), pt(24.0, -8.0), pt(24.0, 8.0)], Color32::from_rgb(242, 208, 152), Stroke::NONE));
    painter.add(Shape::convex_polygon(vec![pt(0.0, 0.0), pt(10.0, -3.8), pt(10.0, 3.8)], Color32::from_rgb(58, 62, 74), Stroke::NONE));
    painter.add(Shape::convex_polygon(quad(24.0, 92.0, -8.0, 8.0), Color32::from_rgb(255, 202, 40), Stroke::NONE));
    painter.add(Shape::convex_polygon(quad(24.0, 92.0, 0.0, 8.0), Color32::from_rgb(238, 168, 20), Stroke::NONE));
    painter.add(Shape::convex_polygon(quad(92.0, 104.0, -8.0, 8.0), Color32::from_rgb(174, 181, 194), Stroke::NONE));
    painter.add(Shape::convex_polygon(quad(104.0, 118.0, -8.0, 8.0), Color32::from_rgb(240, 122, 142), Stroke::NONE));
    // Green check badge on the folder.
    painter.circle_filled(p(78.0, 120.0), 24.0 * s, Color32::from_rgb(46, 170, 110));
    painter.add(Shape::line(vec![p(67.0, 120.0), p(75.0, 129.0), p(90.0, 110.0)], Stroke::new(4.5 * s, Color32::WHITE)));
    // Sparkles.
    for (x, y, size, c) in [(300.0, 44.0, 12.0, Color32::from_rgb(64, 140, 230)), (112.0, 38.0, 8.0, Color32::from_rgb(244, 182, 52)), (324.0, 124.0, 7.0, Color32::from_rgb(64, 140, 230))] {
        let w = Stroke::new(2.6 * s, c);
        painter.line_segment([p(x - size, y), p(x + size, y)], w);
        painter.line_segment([p(x, y - size), p(x, y + size)], w);
        painter.circle_filled(p(x, y), 2.4 * s, c);
    }
}

/// The text on Android's clipboard, if any.
fn clipboard_text(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardText").filter(|text| !text.is_empty())
}

/// The formatted (HTML) copy on Android's clipboard, if another app put one there.
fn clipboard_html(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardHtml").filter(|html| !html.is_empty())
}

/// A picture on Android's clipboard, as the file Java saved it in.
fn clipboard_picture(app: &AndroidApp) -> Option<ClipboardPicture> {
    let path = read_string(app, "clipboardImagePath").filter(|p| !p.is_empty())?;
    let bytes = std::fs::read(path).ok()?;
    (!bytes.is_empty()).then_some(ClipboardPicture::Encoded(bytes))
}

/// What kinds of things are on Android's clipboard (for "nothing to paste" messages).
fn clipboard_formats(app: &AndroidApp) -> Vec<String> {
    read_string(app, "clipboardFormats").map(|s| s.lines().filter(|l| !l.is_empty()).map(str::to_string).collect()).unwrap_or_default()
}

/// Put text (and, if given, its HTML) on Android's clipboard.
fn set_clipboard(app: &AndroidApp, text: &str, html: Option<&str>) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(text)?;
        let html = env.new_string(html.unwrap_or(""))?;
        env.call_method(activity, "setClipboard", "(Ljava/lang/String;Ljava/lang/String;)V", &[JValue::from(&text), JValue::from(&html)])?;
        Ok(())
    })
    .is_some()
}

/// What WordCraft copies (egui's "copy text" requests) goes on Android's clipboard for other apps.
fn bridge_clipboard(ctx: &egui::Context, app: &AndroidApp) {
    let formatted_just_now = HTML_COPIED.lock().ok().and_then(|at| *at).is_some_and(|at| at.elapsed() < Duration::from_millis(1500));
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::CopyText(text) => {
                if !formatted_just_now {
                    set_clipboard(app, text, None);
                }
                false
            }
            _ => true,
        });
    });
}

/// Ask the Java activity to look up the newest release of `repo` (the answer comes by `poll_update`).
fn start_update_check(app: &AndroidApp, repo: &str) {
    with_activity(app, |env, activity| {
        let repo = env.new_string(repo)?;
        env.call_method(activity, "startUpdateCheck", "(Ljava/lang/String;)V", &[JValue::from(&repo)])?;
        Ok(())
    });
}

/// The answer of the update check: "OK" with the tag, page and APK address on lines, or "NONE" when it failed.
fn poll_update(app: &AndroidApp) -> Option<String> {
    read_string(app, "pollUpdate").filter(|reply| !reply.is_empty())
}

/// Show or hide the on-screen keyboard, connected to the hidden input view.
fn show_keyboard(app: &AndroidApp, show: bool) {
    with_activity(app, |env, activity| {
        env.call_method(activity, "showKeyboard", "(Z)V", &[JValue::Bool(u8::from(show))])?;
        Ok(())
    });
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.hyperlink` and the app's own "open URL" requests end up as egui commands; open them here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                if open.url == "android-app://share-log" {
                    with_activity(app, |env, activity| {
                        env.call_method(activity, "shareLog", "()V", &[])?;
                        Ok(())
                    });
                } else {
                    open_link(app, &open.url);
                }
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("WordCraft").with_max_level(log::LevelFilter::Info));
    if std::env::var_os("HOME").is_none() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe { std::env::set_var("HOME", "/storage/emulated/0") };
    }
    let private = app.internal_data_path();
    if let Some(dir) = &private {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe {
            std::env::set_var("HOME", dir);
            std::env::set_var("XDG_CONFIG_HOME", dir.join("config"));
            std::env::set_var("XDG_DATA_HOME", dir.join("data"));
            std::env::set_var("XDG_CACHE_HOME", dir.join("cache"));
        }
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "WordCraft",
        options,
        Box::new(move |cc| {
            let region = wordcraft_ui_egui::i18n::system_region();
            let doc = wordcraft_engine::blank_document(&region);
            let mut session = Session::new(doc);
            session.system_region = region;
            // Android's own picker; if it can't be shown, answer with an error and the app uses its own browser.
            let ctx = cc.egui_ctx.clone();
            let picker = android.clone();
            let file_dialog: Box<dyn Fn(FileDialogRequest) -> mpsc::Receiver<FileDialogAnswer>> = Box::new(move |request| {
                let (answer, rx) = mpsc::channel();
                let (save, name, purpose) = match &request {
                    FileDialogRequest::Open { purpose } => (false, String::new(), purpose.clone()),
                    // Several files: the Java side sees the "multi:" prefix and lets the user pick more than one.
                    FileDialogRequest::OpenMany { purpose } => (false, String::new(), format!("multi:{purpose}")),
                    FileDialogRequest::Save { name, .. } => (true, name.clone(), String::new()),
                };
                let shown = start_pick(&picker, save, &name, &purpose);
                match (shown, EXTERNAL.lock()) {
                    (true, Ok(mut waiting)) => *waiting = Some(answer),
                    _ => {
                        let _ = answer.send(Err("no system file dialog on Android".to_string()));
                    }
                }
                ctx.request_repaint();
                rx
            });
            let (reader, html_reader, writer) = (android.clone(), android.clone(), android.clone());
            let (picture_reader, formats_reader) = (android.clone(), android.clone());
            let services = Services {
                file_dialog: Some(file_dialog),
                // Paste from the ribbon and the context menu reads Android's clipboard.
                clipboard_text: Some(Box::new(move || clipboard_text(&reader))),
                clipboard_html: Some(Box::new(move || clipboard_html(&html_reader))),
                clipboard_picture: Some(Box::new(move || clipboard_picture(&picture_reader))),
                clipboard_formats: Some(Box::new(move || clipboard_formats(&formats_reader))),
                // (html, text, and for a copied equation its MathML: Android has no place for that, so it is not kept)
                set_clipboard_html: Some(Box::new(move |html: &str, text: &str, _mathml: &str| {
                    if let Ok(mut at) = HTML_COPIED.lock() {
                        *at = Some(Instant::now());
                    }
                    set_clipboard(&writer, text, Some(html))
                })),
                ..Default::default()
            };
            let mut word = WordApp::new(session, services);
            // Interface settings and recent documents saved by an earlier run.
            let prefs_path = private.as_ref().map(|dir| dir.join("config").join("ui.json"));
            let prefs_ok = prefs_path.is_some();
            if let Some(path) = &prefs_path
                && let Ok(bytes) = std::fs::read(path)
            {
                match UiState::from_json(&bytes) {
                    Some(ui) => word.apply_prefs(ui),
                    None => {
                        // Keep the unreadable file aside and start fresh, so settings are remembered from now on.
                        log::warn!("settings in {} could not be read; they were set aside", path.display());
                        let _ = std::fs::rename(path, path.with_extension("json.bad"));
                    }
                }
            }
            // Autosaved copies of unsaved documents, offered again after a crash or a swiped-away app.
            if let Some(dir) = &private {
                let wake = cc.egui_ctx.clone();
                if let Err(error) = word.session.enable_recovery(dir.join("config").join("recovery"), Arc::new(move || wake.request_repaint())) {
                    log::warn!("local recovery unavailable: {error}");
                }
            }
            word.start_screen();
            // First run: explain what the app needs before Android is asked for anything.
            let welcome_skip = private.as_ref().map(|dir| dir.join("config").join("welcome-skipped"));
            let welcome = !files_access(&android) && !welcome_skip.as_ref().is_some_and(|f| f.exists());
            if files_access(&android) {
                move_private_documents(&android);
            }
            let update_file = private.as_ref().map(|dir| dir.join("config").join("update.json"));
            let update_choice = update_file.as_deref().map(load_update_choice).unwrap_or_default();
            Ok(Box::new(App {
                word,
                android,
                prefs_path,
                saved: Vec::new(),
                last_check: Instant::now(),
                prefs_ok,
                launched: Instant::now(),
                update_started: false,
                update_choice,
                update_file,
                update_offer: None,
                touch: Touch::default(),
                last_autosave: Instant::now(),
                ime_wanted: false,
                last_theme: String::new(),
                welcome,
                welcome_skip,
                access_checked: Instant::now(),
                dark: None,
                dark_read: Instant::now().checked_sub(Duration::from_secs(5)).unwrap_or_else(Instant::now),
                auto: None,
                rename_checked: Instant::now(),
            }))
        }),
    );
    if let Err(error) = result {
        log::error!("WordCraft failed to start: {error}");
    }
}

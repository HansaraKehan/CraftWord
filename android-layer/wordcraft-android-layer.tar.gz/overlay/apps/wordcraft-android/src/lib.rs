//! WordCraft for Android: runs the shared egui UI (`wordcraft-ui-egui`) inside a NativeActivity.
//!
//! - File ▸ Open / Save As use Android's own file picker (no storage permission needed): the Java
//!   activity copies the chosen document to a private folder and writes later saves back to it. If the
//!   picker can't be shown, the built-in file browser is used (it needs "All files access").
//! - Files opened from other apps ("Open with" WordCraft) arrive through the Java activity, which
//!   copies them to a folder and hands the path over; `poll_open` picks it up on every few frames.
//! - Not yet: preferences file, printing.
#![cfg(target_os = "android")]

use std::path::PathBuf;
use std::sync::{Arc, Mutex, mpsc};
use std::time::{Duration, Instant};

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use wordcraft_engine::Session;
use wordcraft_ui_egui::{FileDialogAnswer, FileDialogRequest, Services, UiState, WordApp};

/// The answer channel of a file dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<FileDialogAnswer>>> = Mutex::new(None);

/// When the last formatted copy was put on the Android clipboard: egui also reports the plain text of
/// that copy, which must not replace it.
static HTML_COPIED: Mutex<Option<Instant>> = Mutex::new(None);

struct App {
    word: WordApp,
    android: AndroidApp,
    /// `<private>/config/ui.json`, the last bytes written to it, when we last looked, and whether it is
    /// safe to overwrite (it was missing or read fine).
    prefs_path: Option<PathBuf>,
    saved: Vec<u8>,
    last_check: Instant,
    prefs_ok: bool,
}

impl App {
    /// Android never closes the app politely, so the desktop's "save when quitting" never runs: write the
    /// interface settings and recent documents a few seconds after they change instead.
    fn save_prefs(&mut self) {
        if !self.prefs_ok || self.last_check.elapsed() < Duration::from_secs(4) {
            return;
        }
        self.last_check = Instant::now();
        let Some(path) = &self.prefs_path else { return };
        let Ok(bytes) = serde_json::to_vec_pretty(&self.word.prefs()) else { return };
        if bytes == self.saved {
            return;
        }
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        // Temporary file, then rename: an interrupted write leaves the previous settings in place.
        let tmp = path.with_extension("json.tmp");
        if std::fs::write(&tmp, &bytes).and_then(|()| std::fs::rename(&tmp, path)).is_ok() {
            self.saved = bytes;
        }
    }
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android)
            && let Err(error) = self.word.run("file.open", serde_json::json!({ "path": path }))
        {
            log::warn!("open {path}: {error}");
        }
        if let Some(answer) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(answer);
        }
        self.word.logic(ctx);
        self.save_prefs();
        // Wake now and then to see a document another app handed us.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        // Ctrl+V: egui only knows what was copied inside the app; paste what is on Android's clipboard.
        for event in raw.events.iter_mut() {
            if let egui::Event::Paste(text) = event
                && let Some(system) = clipboard_text(&self.android)
            {
                *text = system;
            }
        }
        self.word.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.word.ui(ui);
        open_links(ui.ctx(), &self.android);
        bridge_clipboard(ui.ctx(), &self.android);
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

/// Ask the Java activity for the next document opened from another app (a path, or nothing).
fn poll_open(app: &AndroidApp) -> Option<String> {
    let path = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })?;
    (!path.is_empty()).then_some(path)
}

/// Show Android's file picker. `false` means it could not be opened.
fn start_pick(app: &AndroidApp, save: bool, name: &str, purpose: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        let purpose = env.new_string(purpose)?;
        env.call_method(
            activity,
            "startPick",
            "(ZLjava/lang/String;Ljava/lang/String;)V",
            &[JValue::Bool(u8::from(save)), JValue::from(&name), JValue::from(&purpose)],
        )?;
        Ok(())
    })
    .is_some()
}

/// The picker's answer once it has closed: the path to open or save to, or cancelled.
fn poll_pick(app: &AndroidApp) -> Option<FileDialogAnswer> {
    let answer = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollPick", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let answer: String = env.get_string(&text)?.into();
        Ok(answer)
    })?;
    if answer.is_empty() {
        return None;
    }
    Some(Ok(answer.strip_prefix("OK\n").map(str::to_string)))
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

/// The text on Android's clipboard, if any.
fn clipboard_text(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardText").filter(|text| !text.is_empty())
}

/// The formatted (HTML) copy on Android's clipboard, if another app put one there.
fn clipboard_html(app: &AndroidApp) -> Option<String> {
    read_string(app, "clipboardHtml").filter(|html| !html.is_empty())
}

/// Put text (and, if given, its HTML) on Android's clipboard.
fn set_clipboard(app: &AndroidApp, text: &str, html: Option<&str>) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(text)?;
        let html = env.new_string(html.unwrap_or(""))?;
        env.call_method(activity, "setClipboard", "(Ljava/lang/String;Ljava/lang/String;)V", &[JValue::from(&text), JValue::from(&html)])?;
        Ok(())
    })
    .is_some()
}

/// What WordCraft copies (egui's "copy text" requests) goes on Android's clipboard for other apps.
fn bridge_clipboard(ctx: &egui::Context, app: &AndroidApp) {
    let formatted_just_now = HTML_COPIED.lock().ok().and_then(|at| *at).is_some_and(|at| at.elapsed() < Duration::from_millis(1500));
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::CopyText(text) => {
                if !formatted_just_now {
                    set_clipboard(app, text, None);
                }
                false
            }
            _ => true,
        });
    });
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.hyperlink` and the app's own "open URL" requests end up as egui commands; open them here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("WordCraft").with_max_level(log::LevelFilter::Info));
    if std::env::var_os("HOME").is_none() {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe { std::env::set_var("HOME", "/storage/emulated/0") };
    }
    let private = app.internal_data_path();
    if let Some(dir) = &private {
        // SAFETY: nothing else has started threads that read the environment yet.
        unsafe {
            std::env::set_var("HOME", dir);
            std::env::set_var("XDG_CONFIG_HOME", dir.join("config"));
            std::env::set_var("XDG_DATA_HOME", dir.join("data"));
            std::env::set_var("XDG_CACHE_HOME", dir.join("cache"));
        }
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "WordCraft",
        options,
        Box::new(move |cc| {
            let region = wordcraft_ui_egui::i18n::system_region();
            let doc = wordcraft_engine::blank_document(&region);
            let mut session = Session::new(doc);
            session.system_region = region;
            // Android's own picker; if it can't be shown, answer with an error and the app uses its own browser.
            let ctx = cc.egui_ctx.clone();
            let picker = android.clone();
            let file_dialog: Box<dyn Fn(FileDialogRequest) -> mpsc::Receiver<FileDialogAnswer>> = Box::new(move |request| {
                let (answer, rx) = mpsc::channel();
                let (save, name, purpose) = match &request {
                    FileDialogRequest::Open { purpose } => (false, String::new(), purpose.clone()),
                    FileDialogRequest::Save { name } => (true, name.clone(), String::new()),
                };
                let shown = start_pick(&picker, save, &name, &purpose);
                match (shown, EXTERNAL.lock()) {
                    (true, Ok(mut waiting)) => *waiting = Some(answer),
                    _ => {
                        let _ = answer.send(Err("no system file dialog on Android".to_string()));
                    }
                }
                ctx.request_repaint();
                rx
            });
            let (reader, html_reader, writer) = (android.clone(), android.clone(), android.clone());
            let services = Services {
                file_dialog: Some(file_dialog),
                // Paste from the ribbon and the context menu reads Android's clipboard.
                clipboard_text: Some(Box::new(move || clipboard_text(&reader))),
                clipboard_html: Some(Box::new(move || clipboard_html(&html_reader))),
                set_clipboard_html: Some(Box::new(move |html: &str, text: &str| {
                    if let Ok(mut at) = HTML_COPIED.lock() {
                        *at = Some(Instant::now());
                    }
                    set_clipboard(&writer, text, Some(html))
                })),
                ..Default::default()
            };
            let mut word = WordApp::new(session, services);
            // Interface settings and recent documents saved by an earlier run.
            let prefs_path = private.as_ref().map(|dir| dir.join("config").join("ui.json"));
            let mut prefs_ok = prefs_path.is_some();
            if let Some(path) = &prefs_path
                && let Ok(bytes) = std::fs::read(path)
            {
                match UiState::from_json(&bytes) {
                    Some(ui) => word.apply_prefs(ui),
                    None => {
                        log::warn!("settings in {} could not be read; they will not be overwritten", path.display());
                        prefs_ok = false;
                    }
                }
            }
            // Autosaved copies of unsaved documents, offered again after a crash or a swiped-away app.
            if let Some(dir) = &private {
                let wake = cc.egui_ctx.clone();
                if let Err(error) = word.session.enable_recovery(dir.join("config").join("recovery"), Arc::new(move || wake.request_repaint())) {
                    log::warn!("local recovery unavailable: {error}");
                }
            }
            word.start_screen();
            Ok(Box::new(App { word, android, prefs_path, saved: Vec::new(), last_check: Instant::now(), prefs_ok }))
        }),
    );
    if let Err(error) = result {
        log::error!("WordCraft failed to start: {error}");
    }
}

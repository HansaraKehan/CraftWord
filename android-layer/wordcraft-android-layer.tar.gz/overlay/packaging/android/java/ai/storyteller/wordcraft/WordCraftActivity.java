package ai.storyteller.wordcraft;

import android.app.NativeActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * NativeActivity that runs full screen, asks once for "All files access" (so the built-in file
 * browser can see documents), and receives documents other apps open with WordCraft.
 */
public class WordCraftActivity extends NativeActivity {
    private final ConcurrentLinkedQueue<String> opened = new ConcurrentLinkedQueue<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        getWindow().setAttributes(params);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        askForFilesAccessOnce();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    /** Called from Rust: the next document another app opened with us (a file path), or "". */
    public String pollOpen() {
        String path = opened.poll();
        return path == null ? "" : path;
    }

    private void askForFilesAccessOnce() {
        if (Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) return;
        SharedPreferences prefs = getSharedPreferences("wordcraft", Context.MODE_PRIVATE);
        if (prefs.getBoolean("asked_files_access", false)) return;
        prefs.edit().putBoolean("asked_files_access", true).apply();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            // No settings page for it on this device: the app still runs.
        }
    }

    private void handleIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return;
        final Uri uri = intent.getData();
        if (uri == null) return;
        intent.setData(null);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String path = importDocument(uri);
                    if (path != null) opened.add(path);
                } catch (Exception e) {
                    // The document could not be read; nothing is opened.
                }
            }
        }).start();
    }

    /** Copy the document into a folder we can open it from and return its path. */
    private String importDocument(Uri uri) throws Exception {
        if ("file".equals(uri.getScheme()) && uri.getPath() != null && new File(uri.getPath()).canRead()) {
            return uri.getPath();
        }
        String name = "document.docx";
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        String shown = cursor.getString(0);
                        if (shown != null && !shown.isEmpty()) name = shown;
                    }
                } finally {
                    cursor.close();
                }
            }
        } else if (uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
        }
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        File out = uniqueFile(openedFolder(), name);
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return null;
        try {
            OutputStream os = new FileOutputStream(out);
            try {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            } finally {
                os.close();
            }
        } finally {
            in.close();
        }
        return out.getAbsolutePath();
    }

    /** Documents/WordCraft when we have all-files access (the copy survives and Save works), else the cache. */
    private File openedFolder() {
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "WordCraft");
            if (dir.isDirectory() || dir.mkdirs()) return dir;
        }
        File dir = new File(getCacheDir(), "opened");
        dir.mkdirs();
        return dir;
    }

    private static File uniqueFile(File dir, String name) {
        File file = new File(dir, name);
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; file.exists(); i++) file = new File(dir, stem + " (" + i + ")" + ext);
        return file;
    }
}

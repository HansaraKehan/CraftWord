package ai.storyteller.wordcraft;

import android.app.NativeActivity;
import android.content.ClipData;
import android.widget.FrameLayout;
import android.view.KeyEvent;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import android.view.inputmethod.InputContentInfo;
import android.util.Log;
import android.provider.Settings;
import android.os.Environment;
import android.os.Build;
import android.os.Looper;
import android.widget.Toast;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.BaseInputConnection;
import android.view.ViewGroup;
import android.text.InputType;
import android.view.WindowManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * NativeActivity that runs full screen, opens web links, and handles documents without any storage
 * permission: File > Open / Save As use Android's own picker (Storage Access Framework); the chosen
 * document is copied to a private folder, WordCraft works on that copy, and every later save is
 * written back to the original location. Other apps can open documents with WordCraft the same way.
 */
public class WordCraftActivity extends NativeActivity {
    private static final int REQ_PICK = 4711;

    private static class Tracked {
        Uri uri;
        long synced;
        long failedFor;
        Tracked(Uri uri, long synced) {
            this.uri = uri;
            this.synced = synced;
        }
    }

    private final ConcurrentLinkedQueue<String> opened = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> picked = new ConcurrentLinkedQueue<>();
    private final Map<String, Tracked> tracked = new HashMap<>();
    private boolean pickSave;
    private final ConcurrentLinkedQueue<String> typed = new ConcurrentLinkedQueue<>();
    private ImeLayout ime;
    private View nativeView;
    private volatile boolean wantKeyboard;
    private final ConcurrentLinkedQueue<String> pictures = new ConcurrentLinkedQueue<>();
    private static final String TAG = "WordCraft";
    private boolean pickMany;
    private final ConcurrentLinkedQueue<String> updates = new ConcurrentLinkedQueue<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        getWindow().setAttributes(params);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        loadTracked();
        try {
            // The app's own view cannot offer the keyboard a text connection. Wrap it in a layout that can, and that is
            // the only focusable view, so the keyboard never has two views to choose between.
            ViewGroup content = (ViewGroup) findViewById(android.R.id.content);
            if (content != null && content.getChildCount() == 1) {
                nativeView = content.getChildAt(0);
                content.removeViewAt(0);
                ime = new ImeLayout(this);
                ime.addView(nativeView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                content.addView(ime, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                ime.requestFocus();
                Log.i(TAG, "input layout installed; focused=" + ime.hasFocus());
            } else {
                Log.w(TAG, "input layout NOT installed: content children=" + (content == null ? -1 : content.getChildCount()));
            }
        } catch (Exception e) {
            Log.e(TAG, "input layout failed", e);
            ime = null; // the keyboard keeps working the old way
        }
        askForFilesAccessOnce();
        startSyncThread();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused && ime != null) ime.requestFocus();
        if (focused) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    /** Called from Rust: the next document another app opened with us (a file path), or "". */
    public String pollOpen() {
        String path = opened.poll();
        return path == null ? "" : path;
    }

    /** Called from Rust: the picker's answer ("CANCEL", or "OK" and a path on the next line), or "". */
    public String pollPick() {
        String answer = picked.poll();
        return answer == null ? "" : answer;
    }

    /** Called from Rust: show Android's file picker for Open (save = false) or Save As. */
    public void startPick(final boolean save, final String name, final String purpose) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    pickSave = save;
                    pickMany = purpose != null && purpose.startsWith("multi:");
                    Intent intent;
                    if (save) {
                        intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType(mimeFor(name));
                        intent.putExtra(Intent.EXTRA_TITLE, name);
                    } else {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType(purpose != null && purpose.endsWith("picture") ? "image/*" : "*/*");
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, pickMany);
                    }
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, REQ_PICK);
                } catch (Exception e) {
                    picked.add("CANCEL");
                }
            }
        });
    }

    @Override protected void onActivityResult(int request, int result, final Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQ_PICK) return;
        if (result != RESULT_OK || data == null || (data.getData() == null && data.getClipData() == null)) {
            picked.add("CANCEL");
            return;
        }
        final boolean save = pickSave;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    ArrayList<Uri> uris = new ArrayList<>();
                    ClipData clip = data.getClipData();
                    if (clip != null) {
                        for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
                    } else {
                        uris.add(data.getData());
                    }
                    StringBuilder answer = new StringBuilder("OK");
                    for (Uri uri : uris) {
                        keepAccess(uri);
                        String path = save ? prepareSave(uri) : importDocument(uri);
                        if (path != null) answer.append('\n').append(path);
                    }
                    picked.add(answer.toString());
                } catch (Exception e) {
                    picked.add("CANCEL");
                }
            }
        }).start();
    }

    /** Called from Rust: the version of the installed app (the release it was built as). */
    public String installedVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "" : info.versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Called from Rust: look up the newest release of a GitHub repository. */
    public void startUpdateCheck(final String repo) {
        new Thread(new Runnable() {
            @Override public void run() {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo + "/releases/latest").openConnection();
                    connection.setRequestProperty("Accept", "application/vnd.github+json");
                    connection.setRequestProperty("User-Agent", "WordCraft-Android");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    if (connection.getResponseCode() != 200) {
                        updates.add("NONE");
                        return;
                    }
                    InputStream in = connection.getInputStream();
                    java.io.ByteArrayOutputStream body = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) > 0 && body.size() < 512 * 1024) body.write(buffer, 0, n);
                    in.close();
                    JSONObject release = new JSONObject(body.toString("UTF-8"));
                    String apk = "";
                    JSONArray assets = release.optJSONArray("assets");
                    if (assets != null) {
                        for (int i = 0; i < assets.length() && apk.isEmpty(); i++) {
                            String url = assets.getJSONObject(i).optString("browser_download_url", "");
                            if (url.endsWith(".apk")) apk = url;
                        }
                    }
                    updates.add("OK\n" + release.optString("tag_name", "") + "\n" + release.optString("html_url", "") + "\n" + apk);
                } catch (Exception e) {
                    updates.add("NONE");
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        }).start();
    }

    /** Called from Rust: the answer of the update check ("OK" and details, or "NONE"), or "". */
    public String pollUpdate() {
        String answer = updates.poll();
        return answer == null ? "" : answer;
    }

    private ClipboardManager clipboard() {
        return (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
    }

    /** Run on the UI thread and wait: Android only lets the foreground UI read the clipboard dependably. */
    private String onUiThread(final java.util.concurrent.Callable<String> job) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            try {
                String result = job.call();
                return result == null ? "" : result;
            } catch (Exception e) {
                return "";
            }
        }
        final String[] out = {""};
        final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    String result = job.call();
                    out[0] = result == null ? "" : result;
                } catch (Exception e) {
                    out[0] = "";
                }
                done.countDown();
            }
        });
        try {
            done.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            // Give up waiting: nothing is pasted.
        }
        return out[0];
    }

    /** The clipboard text, read on the thread we are on (the keyboard calls us on the UI thread). */
    private String clipboardTextNow() {
        try {
            ClipData data = clipboard().getPrimaryClip();
            if (data == null || data.getItemCount() == 0) return "";
            CharSequence value = data.getItemAt(0).coerceToText(this);
            return value == null ? "" : value.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /** Called from Rust: the text on the clipboard, or "". */
    public String clipboardText() {
        return onUiThread(new java.util.concurrent.Callable<String>() {
            @Override public String call() {
                ClipData data = clipboard().getPrimaryClip();
                if (data == null || data.getItemCount() == 0) return "";
                // A copied picture often carries its address as text too: leave that out, so Paste inserts the picture.
                ClipDescription kinds = data.getDescription();
                for (int i = 0; i < kinds.getMimeTypeCount(); i++) {
                    if (kinds.getMimeType(i).startsWith("image/") && data.getItemAt(0).getUri() != null) return "";
                }
                CharSequence value = data.getItemAt(0).coerceToText(WordCraftActivity.this);
                return value == null ? "" : value.toString();
            }
        });
    }

    /** Called from Rust: the kinds of things on the clipboard (MIME types, one per line), for "nothing to paste" messages. */
    public String clipboardFormats() {
        return onUiThread(new java.util.concurrent.Callable<String>() {
            @Override public String call() {
                ClipData data = clipboard().getPrimaryClip();
                if (data == null) return "";
                ClipDescription description = data.getDescription();
                StringBuilder out = new StringBuilder();
                for (int i = 0; i < description.getMimeTypeCount(); i++) out.append(description.getMimeType(i)).append('\n');
                return out.toString();
            }
        });
    }

    /** Called from Rust: when a picture is on the clipboard, a file holding it; otherwise "". */
    public String clipboardImagePath() {
        return onUiThread(new java.util.concurrent.Callable<String>() {
            @Override public String call() throws Exception {
                ClipData data = clipboard().getPrimaryClip();
                if (data == null || data.getItemCount() == 0) return "";
                ClipDescription description = data.getDescription();
                boolean image = false;
                for (int i = 0; i < description.getMimeTypeCount(); i++) {
                    if (description.getMimeType(i).startsWith("image/")) image = true;
                }
                Uri uri = data.getItemAt(0).getUri();
                if (!image || uri == null) return "";
                Log.i(TAG, "clipboard holds a picture: " + description.getMimeType(0));
                File out = new File(getCacheDir(), "clipboard-picture");
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) return "";
                try {
                    OutputStream os = new FileOutputStream(out);
                    try {
                        byte[] buffer = new byte[64 * 1024];
                        int n;
                        while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
                    } finally {
                        os.close();
                    }
                } finally {
                    in.close();
                }
                return out.getAbsolutePath();
            }
        });
    }

    /** Called from Rust: the formatted (HTML) copy on the clipboard, or "". */
    public String clipboardHtml() {
        return onUiThread(new java.util.concurrent.Callable<String>() {
            @Override public String call() {
                ClipData data = clipboard().getPrimaryClip();
                if (data == null || data.getItemCount() == 0) return "";
                String html = data.getItemAt(0).getHtmlText();
                return html == null ? "" : html;
            }
        });
    }

    /** Called from Rust: put text (and, when not empty, its HTML) on the clipboard. */
    public void setClipboard(final String text, final String html) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    ClipData clip = (html == null || html.isEmpty())
                        ? ClipData.newPlainText("WordCraft", text)
                        : ClipData.newHtmlText("WordCraft", text, html);
                    clipboard().setPrimaryClip(clip);
                } catch (Exception e) {
                    // The clipboard is not available right now.
                }
            }
        });
    }

    private static boolean allFilesAccess() {
        return Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager();
    }

    /** Ask once for "All files access", so new documents can be kept in Documents/WordCraft where you can see them. */
    private void askForFilesAccessOnce() {
        if (Build.VERSION.SDK_INT < 30 || allFilesAccess()) return;
        SharedPreferences prefs = getSharedPreferences("wordcraft", Context.MODE_PRIVATE);
        if (prefs.getBoolean("asked_files_access", false)) return;
        prefs.edit().putBoolean("asked_files_access", true).apply();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            // This device has no such settings page (some Huawei models): documents are kept inside the app instead.
        }
    }

    /**
     * Called from Rust: where to keep a new document that has no name yet. Documents/WordCraft when we have
     * all-files access; otherwise the app's own folder, which always works.
     */
    public String newDocumentPath() {
        File dir = allFilesAccess()
            ? new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "WordCraft")
            : new File(getFilesDir(), "documents");
        if (!dir.isDirectory() && !dir.mkdirs()) {
            dir = new File(getFilesDir(), "documents");
            dir.mkdirs();
        }
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH-mm-ss", java.util.Locale.US).format(new java.util.Date());
        File file = new File(dir, "Document " + stamp + ".docx");
        for (int i = 2; file.exists(); i++) file = new File(dir, "Document " + stamp + " (" + i + ").docx");
        return file.getAbsolutePath();
    }

    /** Debug log: Ctrl shortcuts from a hardware keyboard, to see whether they reach the app (they are not changed). */
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.isCtrlPressed() && event.getKeyCode() != KeyEvent.KEYCODE_CTRL_LEFT && event.getKeyCode() != KeyEvent.KEYCODE_CTRL_RIGHT) {
            Log.i(TAG, "ctrl key " + KeyEvent.keyCodeToString(event.getKeyCode()) + " action=" + event.getAction()
                    + " meta=0x" + Integer.toHexString(event.getMetaState()) + " device=" + event.getDeviceId());
        }
        return super.dispatchKeyEvent(event);
    }

    /**
     * Holds the app's own view and gives the on-screen keyboard a real text connection. Single letters still go the
     * way they always did (as key presses); whole words and pasted text (the keyboard's clipboard strip) are
     * handed to the app through pollTyped().
     */
    private class ImeLayout extends FrameLayout {
        ImeLayout(Context context) {
            super(context);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        }

        @Override public boolean onCheckIsTextEditor() {
            return true;
        }

        @Override public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
            Log.i(TAG, "keyboard asked for a connection");
            outAttrs.inputType = InputType.TYPE_NULL;
            final String[] pictureTypes = {"image/png", "image/jpeg", "image/gif", "image/webp", "image/*"};
            try {
                EditorInfo.class.getField("contentMimeTypes").set(outAttrs, pictureTypes);
            } catch (Exception e) {
                // Older or restricted system: the extras below still announce it.
            }
            Bundle extras = outAttrs.extras != null ? outAttrs.extras : new Bundle();
            extras.putStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", pictureTypes);
            extras.putStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", pictureTypes);
            outAttrs.extras = extras;
            outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN | EditorInfo.IME_ACTION_NONE;
            return new BaseInputConnection(this, false) {
                @Override public boolean commitText(CharSequence text, int newCursorPosition) {
                    if (text != null && text.length() > 1) {
                        Log.i(TAG, "keyboard handed over " + text.length() + " characters");
                        typed.add(text.toString());
                        return true;
                    }
                    return super.commitText(text, newCursorPosition);
                }

                // Keyboards hand long pastes over as a "paste" action instead of text.
                @Override public boolean performContextMenuAction(int id) {
                    Log.i(TAG, "keyboard menu action " + id);
                    if (id == android.R.id.paste || id == android.R.id.pasteAsPlainText) {
                        String text = clipboardTextNow();
                        Log.i(TAG, "paste action: clipboard has " + text.length() + " characters");
                        if (!text.isEmpty()) {
                            typed.add(text);
                            return true;
                        }
                        return false;
                    }
                    return super.performContextMenuAction(id);
                }

                @Override public boolean sendKeyEvent(KeyEvent event) {
                    if (event.getKeyCode() == KeyEvent.KEYCODE_PASTE) {
                        if (event.getAction() == KeyEvent.ACTION_DOWN) {
                            String text = clipboardTextNow();
                            Log.i(TAG, "paste key: clipboard has " + text.length() + " characters");
                            if (!text.isEmpty()) typed.add(text);
                        }
                        return true;
                    }
                    return super.sendKeyEvent(event);
                }

                @Override public boolean setComposingText(CharSequence text, int newCursorPosition) {
                    Log.i(TAG, "keyboard composing text, " + (text == null ? 0 : text.length()) + " characters");
                    return super.setComposingText(text, newCursorPosition);
                }

                @Override public boolean performEditorAction(int actionCode) {
                    Log.i(TAG, "keyboard editor action " + actionCode);
                    return super.performEditorAction(actionCode);
                }

                // A picture from the keyboard's clipboard strip or a sticker/GIF search.
                @Override public boolean commitContent(InputContentInfo info, int flags, Bundle opts) {
                    try {
                        if ((flags & InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION) != 0) info.requestPermission();
                        File out = new File(getCacheDir(), "keyboard-picture");
                        InputStream in = getContentResolver().openInputStream(info.getContentUri());
                        if (in == null) return false;
                        try {
                            OutputStream os = new FileOutputStream(out);
                            try {
                                byte[] buffer = new byte[64 * 1024];
                                int n;
                                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
                            } finally {
                                os.close();
                            }
                        } finally {
                            in.close();
                        }
                        info.releasePermission();
                        pictures.add(out.getAbsolutePath());
                        Log.i(TAG, "keyboard handed over a picture: " + info.getDescription().getMimeType(0));
                        return true;
                    } catch (Exception e) {
                        Log.e(TAG, "picture from the keyboard failed", e);
                        return false;
                    }
                }

                // Backspace and Delete as key presses, which is what the app understands.
                @Override public boolean deleteSurroundingText(int before, int after) {
                    for (int i = 0; i < before; i++) {
                        sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL));
                        sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL));
                    }
                    for (int i = 0; i < after; i++) {
                        sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_FORWARD_DEL));
                        sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_FORWARD_DEL));
                    }
                    return true;
                }
            };
        }
    }

    /** Whether the keyboard is on screen right now. */
    private boolean keyboardVisible() {
        if (ime == null) return false;
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsets insets = ime.getRootWindowInsets();
            return insets != null && insets.isVisible(android.view.WindowInsets.Type.ime());
        }
        return ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).isAcceptingText();
    }

    /**
     * The native side hides and shows the keyboard on its own around every tap (and its show is ignored because this
     * layout holds the keyboard connection). So after showing, look again a few times and show once more if the keyboard
     * was hidden in between.
     */
    private void keepKeyboardUp() {
        final int[] delays = {80, 200, 400, 800};
        for (final int delay : delays) {
            ime.postDelayed(new Runnable() {
                @Override public void run() {
                    if (!wantKeyboard || ime == null) return;
                    if (!keyboardVisible()) {
                        Log.i(TAG, "keyboard was hidden again after " + delay + " ms: showing it");
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        ime.requestFocus();
                        imm.showSoftInput(ime, 0);
                    }
                }
            }, delay);
        }
    }

    private void tryShowKeyboard(final int attemptsLeft) {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            ime.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            ime.requestFocus();
            if (!imm.isActive(ime)) imm.restartInput(ime);
            boolean shown = imm.showSoftInput(ime, 0);
            Log.i(TAG, "show keyboard: attempts left=" + attemptsLeft + " shown=" + shown + " focus=" + ime.hasFocus()
                + " windowFocus=" + ime.hasWindowFocus() + " active=" + imm.isActive(ime) + " accepting=" + imm.isAcceptingText());
            if (!shown && attemptsLeft > 0) {
                ime.postDelayed(new Runnable() {
                    @Override public void run() {
                        tryShowKeyboard(attemptsLeft - 1);
                    }
                }, 120);
            } else if (!shown && nativeView != null) {
                // Last resort: the way the keyboard was always shown (no clipboard strip, but it appears).
                ime.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
                nativeView.requestFocus();
                imm.showSoftInput(nativeView, 0);
            }
        } catch (Exception e) {
            // The keyboard keeps working the way it did before.
        }
    }

    /** Called from Rust: show or hide the on-screen keyboard. */
    public void showKeyboard(final boolean show) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Log.i(TAG, "showKeyboard(" + show + ") ime=" + (ime != null));
                if (ime == null) return;
                wantKeyboard = show;
                if (show) {
                    tryShowKeyboard(8);
                    keepKeyboardUp();
                } else {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(ime.getWindowToken(), 0);
                }
            }
        });
    }

    /** Called from Rust: text the keyboard handed over (a paste or a whole word), or "". */
    public String pollTyped() {
        String text = typed.poll();
        return text == null ? "" : text;
    }

    /** Called from Rust: a picture the keyboard handed over (a file path), or "". */
    public String pollPicture() {
        String path = pictures.poll();
        return path == null ? "" : path;
    }

    /** Called from Rust: share this app's recent log lines (File > Share debug log), for finding problems. */
    public void shareLog() {
        new Thread(new Runnable() {
            @Override public void run() {
                final StringBuilder text = new StringBuilder();
                text.append("WordCraft debug log\n").append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL)
                    .append(", Android ").append(android.os.Build.VERSION.RELEASE).append(" (API ").append(android.os.Build.VERSION.SDK_INT).append(")\n");
                try {
                    text.append("app version ").append(installedVersion()).append("\n\n");
                    Process process = Runtime.getRuntime().exec(new String[] {"logcat", "-d", "-t", "6000", "-v", "time", "WordCraft:V", "*:W"});
                    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                    String line;
                    StringBuilder lines = new StringBuilder();
                    while ((line = reader.readLine()) != null) lines.append(line).append('\n');
                    reader.close();
                    String all = lines.toString();
                    text.append(all.length() > 150000 ? all.substring(all.length() - 150000) : all);
                } catch (Exception e) {
                    text.append("(could not read the log: ").append(e).append(")");
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("text/plain");
                        send.putExtra(Intent.EXTRA_SUBJECT, "WordCraft debug log");
                        send.putExtra(Intent.EXTRA_TEXT, text.toString());
                        startActivity(Intent.createChooser(send, "Share debug log"));
                    }
                });
            }
        }).start();
    }

    /** Called from Rust: open a web link in the user's browser. */
    public void openLink(final String url) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    // No browser installed: nothing to open.
                }
            }
        });
    }

    private void handleIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return;
        final Uri uri = intent.getData();
        if (uri == null) return;
        intent.setData(null);
        keepAccess(uri);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String path = importDocument(uri);
                    if (path != null) opened.add(path);
                } catch (Exception e) {
                    // The document could not be read; nothing is opened.
                }
            }
        }).start();
    }

    private void keepAccess(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            // Not offered for this document: saves still work for as long as the app runs, or fail quietly.
        }
    }

    /** Copy the document into the app's private folder, remember where it came from, return the copy's path. */
    private String importDocument(Uri uri) throws Exception {
        if ("file".equals(uri.getScheme()) && uri.getPath() != null && new File(uri.getPath()).canRead()) {
            return uri.getPath();
        }
        File out = new File(newDocFolder(), displayName(uri, "document.docx"));
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return null;
        try {
            OutputStream os = new FileOutputStream(out);
            try {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            } finally {
                os.close();
            }
        } finally {
            in.close();
        }
        track(out.getAbsolutePath(), uri, out.lastModified());
        return out.getAbsolutePath();
    }

    /** Save As: WordCraft will write this path; the sync thread copies it to the chosen document. */
    private String prepareSave(Uri uri) {
        File out = new File(newDocFolder(), displayName(uri, "document.docx"));
        track(out.getAbsolutePath(), uri, 0);
        return out.getAbsolutePath();
    }

    private File newDocFolder() {
        File dir = new File(new File(getFilesDir(), "docs"), String.valueOf(System.currentTimeMillis()));
        dir.mkdirs();
        return dir;
    }

    private String displayName(Uri uri, String fallback) {
        String name = fallback;
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        String shown = cursor.getString(0);
                        if (shown != null && !shown.isEmpty()) name = shown;
                    }
                } finally {
                    cursor.close();
                }
            }
        } else if (uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
        }
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private static String mimeFor(String name) {
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (n.endsWith(".odt")) return "application/vnd.oasis.opendocument.text";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".rtf")) return "application/rtf";
        if (n.endsWith(".txt")) return "text/plain";
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        return "application/octet-stream";
    }

    // ---- writing saves back to the original document -------------------------------------

    private void track(String path, Uri uri, long synced) {
        synchronized (tracked) {
            tracked.put(path, new Tracked(uri, synced));
        }
        saveTracked();
    }

    private void saveTracked() {
        Set<String> entries = new HashSet<>();
        synchronized (tracked) {
            for (Map.Entry<String, Tracked> e : tracked.entrySet()) {
                entries.add(e.getKey() + "\t" + e.getValue().uri + "\t" + e.getValue().synced);
            }
        }
        getSharedPreferences("wordcraft", Context.MODE_PRIVATE).edit().putStringSet("tracked", entries).apply();
    }

    private void loadTracked() {
        Set<String> entries = getSharedPreferences("wordcraft", Context.MODE_PRIVATE).getStringSet("tracked", null);
        if (entries == null) return;
        synchronized (tracked) {
            for (String entry : entries) {
                String[] parts = entry.split("\t");
                if (parts.length != 3 || !new File(parts[0]).exists()) continue;
                try {
                    tracked.put(parts[0], new Tracked(Uri.parse(parts[1]), Long.parseLong(parts[2])));
                } catch (NumberFormatException e) {
                    // Skip a damaged entry.
                }
            }
        }
    }

    private void startSyncThread() {
        Thread thread = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException e) {
                        return;
                    }
                    syncBack();
                }
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    /** Copy every private document that changed since the last copy back to its original location. */
    private void syncBack() {
        ArrayList<String> paths;
        synchronized (tracked) {
            paths = new ArrayList<>(tracked.keySet());
        }
        boolean changed = false;
        for (String path : paths) {
            Tracked t;
            synchronized (tracked) {
                t = tracked.get(path);
            }
            File file = new File(path);
            if (t == null || !file.isFile() || file.length() == 0) continue;
            long modified = file.lastModified();
            if (modified == t.synced || modified == t.failedFor || System.currentTimeMillis() - modified < 800) continue;
            try {
                copyToUri(file, t.uri);
                t.synced = modified;
                changed = true;
            } catch (Exception e) {
                t.failedFor = modified; // not writable (a read-only source): try again only after the next save
            }
        }
        if (changed) saveTracked();
    }

    private void copyToUri(File file, Uri uri) throws Exception {
        OutputStream os;
        try {
            os = getContentResolver().openOutputStream(uri, "wt");
        } catch (Exception e) {
            os = getContentResolver().openOutputStream(uri, "w");
        }
        if (os == null) throw new java.io.IOException("no output stream");
        try {
            InputStream in = new FileInputStream(file);
            try {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            } finally {
                in.close();
            }
        } finally {
            os.close();
        }
    }
}

#!/usr/bin/env python3
"""Add the Android layer to a WordCraft checkout. Run from the repository root."""
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()

cargo = ROOT / "Cargo.toml"
text = cargo.read_text(encoding="utf-8")
if 'exclude = ["vendor/winit"]' not in text:
    marker = "members = ["
    i = text.find(marker)
    if i < 0:
        sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
    j = text.index("\n", i)
    text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
if "[patch.crates-io]" in text:
    sys.exit("Cargo.toml already has [patch.crates-io]; the layer needs updating")
text = text.rstrip("\n") + '\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\nwinit = { path = "vendor/winit" }\n'
cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """Link to this repository's Releases page from the About dialog and the File > Help list."""
    import os

    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftWord"
    url = f"https://github.com/{repo}/releases"
    dialogs = ROOT / "crates/ui-egui/src/dialogs.rs"
    backstage = ROOT / "crates/ui-egui/src/backstage.rs"
    done = []
    if dialogs.exists():
        t = dialogs.read_text(encoding="utf-8")
        anchor = '                    ui.hyperlink_to(tl!("Source code: github.com/storytold/wordcraft"), "https://github.com/storytold/wordcraft");'
        if anchor in t and "Get the Android app" not in t:
            t = t.replace(anchor, anchor + '\n                    ui.hyperlink_to(tl!("Get the Android app / updates"), "' + url + '");', 1)
            dialogs.write_text(t, encoding="utf-8")
            done.append("About dialog")
    if backstage.exists():
        t = backstage.read_text(encoding="utf-8")
        old_list = '[("About", "about"), ("Discord community", "discord")]'
        old_click = '                        if id == "discord" {'
        if old_list in t and old_click in t and "androidReleases" not in t:
            t = t.replace(old_list, '[("About", "about"), ("Discord community", "discord"), ("Android app / updates", "androidReleases")]', 1)
            t = t.replace(old_click, '                        if id == "androidReleases" {\n                            app.canvas.open_url = Some("' + url + '".into());\n                        } else if id == "discord" {', 1)
            backstage.write_text(t, encoding="utf-8")
            done.append("File menu")
    print("Releases link added to: " + (", ".join(done) if done else "nowhere (upstream code changed)"))


shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
add_releases_link()
print("Android layer applied")

#!/usr/bin/env python3
"""Add the Android layer to a WordCraft checkout. Run from the repository root."""
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]

def patch_workspace() -> None:
    import re

    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor/winit"]' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
    line = 'winit = { path = "vendor/winit" }'
    if "[patch.crates-io]" in text:
        # Upstream already patches some crates: add ours to that table (replacing its own winit entry, if any).
        text = drop_in_patch_section(text, ["winit"])
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + line + "\n", 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\n" + line + "\n"
    cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """Link to this repository's Releases page from the About dialog and the File > Help list."""
    import os

    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftWord"
    url = f"https://github.com/{repo}/releases"
    dialogs = ROOT / "crates/ui-egui/src/dialogs.rs"
    backstage = ROOT / "crates/ui-egui/src/backstage.rs"
    done = []
    if dialogs.exists():
        t = dialogs.read_text(encoding="utf-8")
        anchor = '                    ui.hyperlink_to(tl!("Source code: github.com/storytold/wordcraft"), "https://github.com/storytold/wordcraft");'
        if anchor in t and "Get the Android app" not in t:
            t = t.replace(anchor, anchor + '\n                    ui.hyperlink_to(tl!("Get the Android app / updates"), "' + url + '");', 1)
            dialogs.write_text(t, encoding="utf-8")
            done.append("About dialog")
    if backstage.exists():
        t = backstage.read_text(encoding="utf-8")
        old_list = '[("About", "about"), ("Discord community", "discord")]'
        old_click = '                        if id == "discord" {'
        if old_list in t and old_click in t and "androidReleases" not in t:
            t = t.replace(old_list, '[("About", "about"), ("Discord community", "discord"), ("Android app / updates", "androidReleases")]', 1)
            t = t.replace(old_click, '                        if id == "androidReleases" {\n                            app.canvas.open_url = Some("' + url + '".into());\n                        } else if id == "discord" {', 1)
            backstage.write_text(t, encoding="utf-8")
            done.append("File menu")
    print("Releases link added to: " + (", ".join(done) if done else "nowhere (upstream code changed)"))


patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
add_releases_link()
print("Android layer applied")

#!/usr/bin/env python3
"""Add the Android layer to a WordCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def developer_url() -> str:
    """The profile of whoever owns the repository this is built in (their GitHub account)."""
    owner = (os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/x").split("/")[0]
    return f"https://github.com/{owner}"


def upstream_patches_winit(text: str) -> bool:
    """Whether the workspace already replaces winit itself (a git fork or its own vendored copy).
    Then ours must stay out of the way: their other libraries need what their winit adds."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return False
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    return re.search(r"(?m)^winit\s*=", text[start:end]) is not None


def sub_all(path: Path, pairs: list, label: str) -> None:
    """Replace text in a source file, everywhere it occurs, and say how many changes were made."""
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    changes = 0
    for old, new in pairs:
        changes += text.count(old)
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"{label}: {changes} change(s)")


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]

def patch_workspace() -> None:
    import re

    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if upstream_patches_winit(text):
        print("winit: upstream already patches it; the Android input patch is not applied")
        return
    if 'exclude = ["vendor/winit"]' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
    line = 'winit = { path = "vendor/winit" }'
    if "[patch.crates-io]" in text:
        # Upstream already patches some crates: add ours to that table (replacing its own winit entry, if any).
        text = drop_in_patch_section(text, ["winit"])
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + line + "\n", 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\n" + line + "\n"
    cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """Link to this repository's Releases page from the About dialog and the File > Help list."""
    import os

    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftWord"
    url = f"https://github.com/{repo}/releases"
    dialogs = ROOT / "crates/ui-egui/src/dialogs.rs"
    backstage = ROOT / "crates/ui-egui/src/backstage.rs"
    done = []
    if dialogs.exists():
        t = dialogs.read_text(encoding="utf-8")
        anchor = '                    ui.hyperlink_to(tl!("Source code: github.com/storytold/wordcraft"), "https://github.com/storytold/wordcraft");'
        if anchor in t and "Get the Android app" not in t:
            t = t.replace(anchor, anchor + '\n                    ui.hyperlink_to(tl!("Get the Android app / updates"), "' + url + '");', 1)
            dialogs.write_text(t, encoding="utf-8")
            done.append("About dialog")
    if backstage.exists():
        t = backstage.read_text(encoding="utf-8")
        old_list = '[("About", "about"), ("Discord community", "discord")]'
        old_click = '                        if id == "discord" {'
        if old_list in t and old_click in t and "androidReleases" not in t:
            t = t.replace(old_list, '[("About", "about"), ("Discord community", "discord"), ("Android app / updates", "androidReleases"), ("Share debug log", "shareLog")]', 1)
            t = t.replace(old_click, '                        if id == "androidReleases" {\n                            app.canvas.open_url = Some("' + url + '".into());\n                        } else if id == "shareLog" {\n                            app.canvas.open_url = Some("android-app://share-log".into());\n                        } else if id == "discord" {', 1)
            backstage.write_text(t, encoding="utf-8")
            done.append("File menu")
    print("Releases link added to: " + (", ".join(done) if done else "nowhere (upstream code changed)"))



def replace_once(path: Path, old: str, new: str, label: str, required: bool = False) -> None:
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    if old in text:
        path.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"{label}: done")
    elif new in text:
        print(f"{label}: already done")
    elif required:
        sys.exit(f"{label}: upstream changed the code this patch needs ({path.name}); the Android layer must be updated")
    else:
        print(f"{label}: skipped (upstream code changed)")


def touch_area() -> None:
    """Tell the Android host where the document is, so a swipe there scrolls and a held finger selects."""
    replace_once(
        ROOT / "crates/ui-egui/src/canvas.rs",
        "    let hovered = wheel_hovered(ui.rect_contains_pointer(wheel_area), ui.ctx().dragged_id().is_some(), app.canvas.drag_selecting());",
        "    // (Android) the document area, for swipe-to-scroll and hold-to-select; none while a dialog is open.\n"
        "    ui.ctx().data_mut(|d| {\n"
        '        let key = egui::Id::new("android.page_rect");\n'
        "        d.insert_temp(key, if app.dialog.is_none() { Some((wheel_area, true)) } else { None::<(egui::Rect, bool)> });\n"
        "    });\n"
        "    let hovered = wheel_hovered(ui.rect_contains_pointer(wheel_area), ui.ctx().dragged_id().is_some(), app.canvas.drag_selecting());",
        "Touch: document area",
        required=True,
    )


def android_fonts() -> None:
    """Android keeps its fonts in /system/fonts (and a few sibling folders): list them next to the desktop ones, so
    documents in Chinese, Arabic, Hindi and other scripts, and anything the device's fonts can draw, show up."""
    replace_once(
        ROOT / "crates/fonts/src/fontdb/names.rs",
        '        dirs.extend(["/usr/share/fonts", "/usr/local/share/fonts"].map(Into::into));',
        '        dirs.extend(["/usr/share/fonts", "/usr/local/share/fonts", "/system/fonts", "/system/product/fonts", "/product/fonts", "/system_ext/fonts", "/vendor/fonts"].map(Into::into));',
        "Android font folders",
    )

def rebrand() -> None:
    """Replace the upstream community (Discord) link with a link to this build's developer on GitHub.
    The licences, copyright notices and the credit to the original project stay where they are."""
    url = developer_url()
    ui = ROOT / "crates/ui-egui/src"
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftWord"
    releases = f"https://github.com/{repo}/releases"
    sub_all(ui / "app/commands.rs", [('"https://discord.gg/artcraft".into()', f'"{url}".into()')], "Community link")
    sub_all(ui / "dialogs/dispatch.rs", [(
        'ui.hyperlink_to(tl!("Join us on Discord: discord.gg/artcraft"), "https://discord.gg/artcraft");',
        f'ui.hyperlink_to(tl!("Follow the developer on GitHub"), "{url}");\n                    ui.hyperlink_to(tl!("Get the Android app / updates"), "{releases}");',
    )], "About dialog")
    sub_all(ui / "ribbon/review.rs", [('big(ui, app, "discord", "Community\\nDiscord", "ui.discord"', 'big(ui, app, "link", "Follow the\\ndeveloper", "ui.discord"')], "Review tab button")
    sub_all(ui / "chrome.rs", [
        ('tl!("Discord")', 'tl!("Follow")'),
        ('tl!("Join the ArtCraft community on Discord")', 'tl!("Follow the developer of this Android build on GitHub")'),
        ('"discord",\n                            t.on_accent,', '"link",\n                            t.on_accent,'),
    ], "Title-bar button")
    sub_all(ui / "keytips.rs", [('c("Community Discord", "ui.discord")', 'c("Follow the developer", "ui.discord")')], "Key tips")
    sub_all(ui / "backstage.rs", [('("Discord community", "discord")', '("Follow the developer", "discord")')], "File menu")

def apply_patches() -> None:
    """Fixes for upstream code, kept as patches in patches/. One that is already in upstream (it reverses
    cleanly) is skipped; one that no longer fits is reported and skipped, so the build is never blocked by it."""
    import subprocess

    for patch in sorted((HERE / "patches").glob("*.patch")):
        def git(*args: str) -> bool:
            return subprocess.run(["git", "apply", "--ignore-whitespace", *args, str(patch)], cwd=ROOT, capture_output=True).returncode == 0
        if git("--check", "--reverse"):
            print(f"{patch.name}: already in upstream")
        elif git("--check"):
            git()
            print(f"{patch.name}: applied")
        else:
            print(f"{patch.name}: skipped (upstream code changed; the patch needs updating)")


def word_fonts() -> None:
    """Android has no Calibri, Cambria, Arial or Times New Roman, so a Word document falls back to fonts with other
    letter widths and lines break elsewhere. Bundle the metric-compatible look-alikes (Carlito, Caladea, Liberation 2:
    same widths as the originals, SIL Open Font Licence), so layout matches Word. They come from the Debian/Ubuntu
    packages on the build machine, each with its licence text, which is kept next to the fonts."""
    import subprocess

    packages = ["fonts-crosextra-carlito", "fonts-crosextra-caladea", "fonts-liberation2"]
    wanted = ("Carlito-", "Caladea-", "LiberationSans-", "LiberationSerif-", "LiberationMono-")

    def listing(pkg: str) -> list:
        out = subprocess.run(["dpkg", "-L", pkg], capture_output=True, text=True)
        files = [f for f in out.stdout.split() if f.endswith(".ttf") and os.path.basename(f).startswith(wanted)]
        return files if out.returncode == 0 else []

    def liberation2(pkg: str) -> bool:
        """Liberation 2.x is under the Open Font Licence; 1.x (GPL with a font exception) is not bundled."""
        v = subprocess.run(["dpkg-query", "-W", "-f=${Version}", pkg], capture_output=True, text=True).stdout
        return v.removeprefix("1:").startswith("2")

    if not (listing("fonts-crosextra-carlito") and listing("fonts-crosextra-caladea") and listing("fonts-liberation")):
        subprocess.run(["sudo", "apt-get", "install", "-y", "-qq", "fonts-crosextra-carlito", "fonts-crosextra-caladea", "fonts-liberation2", "fonts-liberation"], capture_output=True)
    # Ubuntu ships Liberation 2 as `fonts-liberation`; Debian as `fonts-liberation2` (the Ubuntu one is an empty stub).
    packages = packages[:2] + [next((p for p in ("fonts-liberation2", "fonts-liberation") if listing(p) and liberation2(p)), "fonts-liberation2")]
    dest = ROOT / "assets/fonts"
    dest.mkdir(parents=True, exist_ok=True)
    lines, count = "", 0
    for pkg in packages:
        files = listing(pkg)
        licence = Path("/usr/share/doc") / pkg / "copyright"
        if not files or not licence.exists():
            print(f"Word-compatible fonts: {pkg} skipped (not installed, or no licence text to ship with it)")
            continue
        shutil.copy(licence, dest / f"LICENSE-{pkg}.txt")
        for src in sorted(files):
            name = os.path.basename(src)
            shutil.copy(src, dest / name)
            lines += f'    include_bytes!("../../../../assets/fonts/{name}"),\n'
            count += 1
    if not count:
        return
    with open(ROOT / "ATTRIBUTION.md", "a", encoding="utf-8") as f:
        f.write(
            "\n## Fonts added by the Android build\n\n"
            "Carlito and Caladea (Google Crosextra), and Liberation 2 (Red Hat), are bundled as metric-compatible stand-ins for "
            "Calibri, Cambria, Arial, Times New Roman and Courier New, under the SIL Open Font Licence 1.1. "
            "The licence texts are `assets/fonts/LICENSE-fonts-*.txt`.\n"
        )
    replace_once(
        ROOT / "crates/fonts/src/fontdb/face.rs",
        '    include_bytes!("../../../../assets/fonts/JetBrainsMono-Regular.ttf"),\n',
        '    include_bytes!("../../../../assets/fonts/JetBrainsMono-Regular.ttf"),\n' + lines,
        f"Word-compatible fonts ({count} files)",
    )


def android_input_winit() -> None:
    """Upstream builds with its own winit fork (a git revision), which has no hardware mouse, wheel and
    keyboard input on Android: the wheel does nothing, Ctrl/Shift combinations are lost and a mouse can't select.
    Fetch that exact revision, add the Android input patch (winit-patch/) and use that copy instead.
    If anything fails, upstream's winit stays in place and the build still goes ahead."""
    import subprocess
    import tempfile

    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    found = re.search(r'(?m)^winit\s*=\s*\{[^}\n]*git\s*=\s*"([^"]+)"[^}\n]*rev\s*=\s*"([0-9a-f]{7,40})"[^}\n]*\}\s*$', text)
    if not found or not upstream_patches_winit(text):
        print("Android input: skipped (upstream's winit is not a pinned git revision)")
        return
    url, rev = found.group(1), found.group(2)
    dest = ROOT / "vendor/winit-android"
    patch = HERE / "winit-patch"

    def run(*cmd: str, cwd: Path = ROOT) -> None:
        subprocess.run(cmd, cwd=cwd, check=True, capture_output=True)

    try:
        shutil.rmtree(dest, ignore_errors=True)
        dest.parent.mkdir(parents=True, exist_ok=True)
        run("git", "clone", "--quiet", url, str(dest))
        run("git", "checkout", "--quiet", rev, cwd=dest)
        mod = dest / "src/platform_impl/android/mod.rs"
        # The patch is written against the file formatted one fixed way (the fork's own style differs).
        with tempfile.TemporaryDirectory() as tmp:
            for f in (mod.parent).glob("*.rs"):
                shutil.copy(f, tmp)
            Path(tmp, "input_state.rs").touch()
            run("rustfmt", "--edition", "2021", "--config", "max_width=150,use_small_heuristics=Max", str(Path(tmp, "mod.rs")))
            shutil.copy(Path(tmp, "mod.rs"), mod)
        run("git", "apply", str(patch / "android-input.patch"), cwd=dest)
        shutil.copy(patch / "input_state.rs", mod.parent / "input_state.rs")
    except Exception as err:  # noqa: BLE001 - anything: keep upstream's winit
        shutil.rmtree(dest, ignore_errors=True)
        detail = getattr(err, "stderr", b"") or b""
        print(f"Android input: skipped ({err}; {detail.decode(errors='replace')[:300]}). Mouse wheel, Ctrl/Shift shortcuts and mouse selection will not work.")
        return
    shutil.rmtree(dest / ".git", ignore_errors=True)
    if 'exclude = ["vendor/winit-android"]' not in text:
        i = text.find("members = [")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit-android"]\n' + text[j + 1 :]
    text = text.replace(found.group(0), 'winit = { path = "vendor/winit-android" }', 1)
    cargo.write_text(text, encoding="utf-8")
    print(f"Android input: winit {rev[:7]} with the Android mouse/keyboard patch")


keep_theirs = upstream_patches_winit((ROOT / "Cargo.toml").read_text(encoding="utf-8"))
patch_workspace()
android_input_winit()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True, ignore=shutil.ignore_patterns("winit") if keep_theirs else None)
add_releases_link()
touch_area()
android_fonts()
apply_patches()
word_fonts()
rebrand()
print("Android layer applied")

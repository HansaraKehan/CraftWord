#!/usr/bin/env python3
"""Add the Android layer to a WordCraft checkout. Run from the repository root."""
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()

cargo = ROOT / "Cargo.toml"
text = cargo.read_text(encoding="utf-8")
if 'exclude = ["vendor/winit"]' not in text:
    marker = "members = ["
    i = text.find(marker)
    if i < 0:
        sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
    j = text.index("\n", i)
    text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
if "[patch.crates-io]" in text:
    sys.exit("Cargo.toml already has [patch.crates-io]; the layer needs updating")
text = text.rstrip("\n") + '\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\nwinit = { path = "vendor/winit" }\n'
cargo.write_text(text, encoding="utf-8")

shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
print("Android layer applied")
